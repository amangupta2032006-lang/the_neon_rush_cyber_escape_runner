/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';
import { GameState, Lane, PlayerStats, HoverboardSkin, ActiveEntity, RoadChunk } from '../types';
import { gameAudio } from '../components/AudioEngine';

export class GameEngine {
  // Three.js Core
  public scene!: THREE.Scene;
  public camera!: THREE.PerspectiveCamera;
  public renderer!: THREE.WebGLRenderer;
  private clock!: THREE.Clock;

  // Game Settings & State
  public state: GameState = GameState.MENU;
  public stats: PlayerStats = {
    score: 0,
    coins: 0,
    multiplier: 1,
    distance: 0,
    highScore: 0,
    highCoins: 0,
  };

  // Systems State
  public playerLane: Lane = 0;
  public targetLane: Lane = 0;
  public playerX: number = 0;
  public startLaneX: number = 0;
  public laneSwitchProgress: number = 1; // 1 means transition complete
  public laneSwitchDuration: number = 0.18; // Super snappy switch!
  public laneDistance: number = 3.5;

  // Jump and Slide Mechanics
  public isJumping: boolean = false;
  public jumpProgress: number = 0;
  public jumpDuration: number = 0.65;
  public jumpHeight: number = 3.8;

  public isSliding: boolean = false;
  public slideProgress: number = 0;
  public slideDuration: number = 0.75;

  // Speed Boost and Shield
  public speedBoostActive: boolean = false;
  public speedBoostTimer: number = 0;
  public shieldActive: boolean = false;
  public shieldTimer: number = 0;

  // Speeds
  public baseSpeed: number = 26; // Units per second
  public maxSpeed: number = 55;
  public currentSpeed: number = 26;
  public speedIncrement: number = 0.4; // Increments per 100 distance units

  // Player Mesh
  private playerGroup!: THREE.Group;
  private playerMesh!: THREE.Mesh;
  private hoverboardMesh!: THREE.Mesh;
  private shieldBubble!: THREE.Mesh;
  private trailParticles: THREE.Points[] = [];
  private particleCount: number = 40;
  private particleIndex: number = 0;
  private particlePositions!: Float32Array;
  private particleGeometry!: THREE.BufferGeometry;

  // Procedural Road Recycling & Object Pooling
  private roadChunks: RoadChunk[] = [];
  private chunkSize: number = 60;
  private totalVisibleChunks: number = 7;
  private currentChunkZ: number = 0;

  // Mesh Pools to avoid garbage collection
  private coinPool: THREE.Group[] = [];
  private coinPoolIndex: number = 0;
  private obstaclePools: { [key: string]: THREE.Group[] } = {
    BARRIER_LOW: [],
    BARRIER_HIGH: [],
    HOVER_CAR: [],
    DRONE: [],
    RAMP: [],
  };
  private obstaclePoolIndexes: { [key: string]: number } = {
    BARRIER_LOW: 0,
    BARRIER_HIGH: 0,
    HOVER_CAR: 0,
    DRONE: 0,
    RAMP: 0,
  };

  // Environment/City Grid
  private skylineBuildings: THREE.Mesh[] = [];

  // Active Skin
  private activeSkin: HoverboardSkin = {
    id: 'cyber_neon',
    name: 'Cyber Neon',
    color: '#00ffff',
    secondaryColor: '#ff00ff',
    price: 0,
    unlocked: true,
    trailParticles: 40,
    description: 'Classic laser cyan light board.',
  };

  // Keyboard/Touch Buffer state
  private activeKeys: { [key: string]: boolean } = {};
  private touchStartX: number = 0;
  private touchStartY: number = 0;
  private minSwipeDistance: number = 30;

  // React callbacks for UI syncing
  private onStateChange: (state: GameState) => void = () => {};
  private onStatsChange: (stats: PlayerStats) => void = () => {};
  public onLog: (msg: string) => void = () => {};

  constructor() {
    this.clock = new THREE.Clock();
  }

  public init(
    container: HTMLDivElement,
    onStateChange: (state: GameState) => void,
    onStatsChange: (stats: PlayerStats) => void,
    onLog?: (msg: string) => void
  ) {
    this.onStateChange = onStateChange;
    this.onStatsChange = onStatsChange;
    if (onLog) this.onLog = onLog;

    // Load Highscores
    this.loadStats();

    // 1. Scene, Camera, WebGLRenderer
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x06020c);
    this.scene.fog = new THREE.FogExp2(0x06020c, 0.01);

    this.camera = new THREE.PerspectiveCamera(60, container.clientWidth / container.clientHeight, 0.1, 400);
    // Position camera behind and above the player (player starts at z = 0, y = 0)
    this.camera.position.set(0, 5.5, 9);
    this.camera.lookAt(0, 1.5, -15);

    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: 'high-performance' });
    this.renderer.setSize(container.clientWidth, container.clientHeight);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    // Clean up previous canvas if any
    container.innerHTML = '';
    container.appendChild(this.renderer.domElement);

    // 2. Lighting setup
    this.setupLighting();

    // 3. Object pools initialization
    this.initObjectPools();

    // 4. Create Player & Board
    this.createPlayer();

    // 5. Create Skyline & City scenery
    this.createSkyline();

    // 6. Generate initial road segments
    this.generateInitialRoads();

    // 7. Input listeners
    this.setupInput();

    // 8. Start loop
    this.clock.getDelta(); // reset clock
    this.animate();
  }

  private loadStats() {
    const savedHighScore = localStorage.getItem('neon_rush_highscore');
    const savedCoins = localStorage.getItem('neon_rush_total_coins');
    const savedHighCoins = localStorage.getItem('neon_rush_highcoins');

    this.stats.highScore = savedHighScore ? parseInt(savedHighScore, 10) : 0;
    this.stats.highCoins = savedHighCoins ? parseInt(savedHighCoins, 10) : 0;
    this.stats.coins = savedCoins ? parseInt(savedCoins, 10) : 0;
  }

  private saveStats() {
    localStorage.setItem('neon_rush_highscore', String(this.stats.highScore));
    localStorage.setItem('neon_rush_highcoins', String(this.stats.highCoins));
    localStorage.setItem('neon_rush_total_coins', String(this.stats.coins));
  }

  public setSkin(skin: HoverboardSkin) {
    this.activeSkin = skin;
    if (this.hoverboardMesh) {
      // Re-create hoverboard color dynamically
      const mat = this.hoverboardMesh.material as THREE.MeshStandardMaterial;
      if (mat) {
        mat.color.set(skin.color);
        mat.emissive.set(skin.color);
      }
    }
  }

  private setupLighting() {
    // Ambient light with custom deep cyber purple
    const ambientLight = new THREE.AmbientLight(0x180830, 1.2);
    this.scene.add(ambientLight);

    // Dynamic direct cyan sun light
    const dirLight = new THREE.DirectionalLight(0x00ffff, 1.5);
    dirLight.position.set(10, 20, 10);
    dirLight.castShadow = true;
    dirLight.shadow.mapSize.width = 1024;
    dirLight.shadow.mapSize.height = 1024;
    this.scene.add(dirLight);

    // Dynamic warm magenta back-light
    const pointLight = new THREE.PointLight(0xff00bb, 2, 50);
    pointLight.position.set(-10, 8, -5);
    this.scene.add(pointLight);
  }

  private initObjectPools() {
    // 1. Coins Pool: 80 golden coins
    const coinGeom = new THREE.CylinderGeometry(0.7, 0.7, 0.15, 8);
    coinGeom.rotateX(Math.PI / 2); // Make it face player
    const coinMat = new THREE.MeshStandardMaterial({
      color: 0xffdd00,
      emissive: 0xff8800,
      roughness: 0.1,
      metalness: 0.9,
    });

    for (let i = 0; i < 80; i++) {
      const mesh = new THREE.Mesh(coinGeom, coinMat);
      // Add a cool outer neon ring
      const ringGeom = new THREE.RingGeometry(0.85, 0.95, 8);
      const ringMat = new THREE.MeshBasicMaterial({ color: 0xff5500, side: THREE.DoubleSide });
      const ring = new THREE.Mesh(ringGeom, ringMat);
      const group = new THREE.Group();
      group.add(mesh);
      group.add(ring);
      group.castShadow = true;
      group.visible = false;
      this.scene.add(group);
      this.coinPool.push(group);
    }

    // 2. Obstacles pools
    // Low Barrier: Glowing Orange warning block
    const lowBarrierGeom = new THREE.BoxGeometry(3.2, 0.9, 0.8);
    const lowBarrierMat = new THREE.MeshStandardMaterial({
      color: 0xff3300,
      emissive: 0x992200,
      roughness: 0.2,
    });
    for (let i = 0; i < 15; i++) {
      const mesh = new THREE.Mesh(lowBarrierGeom, lowBarrierMat);
      // Warning stripes
      const stripeGeom = new THREE.BoxGeometry(3.3, 0.2, 0.9);
      const stripeMat = new THREE.MeshBasicMaterial({ color: 0x0a0a0d });
      const stripe = new THREE.Mesh(stripeGeom, stripeMat);
      stripe.position.set(0, 0, 0);
      const group = new THREE.Group();
      group.add(mesh);
      group.add(stripe);
      group.visible = false;
      this.scene.add(group);
      this.obstaclePools.BARRIER_LOW.push(group);
    }

    // High Barrier: Glowing Cyan laser fence
    const highBarrierGeom = new THREE.BoxGeometry(3.2, 0.6, 0.6); // Top bar
    const laserGeom = new THREE.PlaneGeometry(3.0, 1.8);
    const highBarrierMat = new THREE.MeshStandardMaterial({ color: 0x00ffcc, emissive: 0x00aa88 });
    const laserMat = new THREE.MeshBasicMaterial({
      color: 0x00ffcc,
      transparent: true,
      opacity: 0.45,
      side: THREE.DoubleSide,
    });
    for (let i = 0; i < 15; i++) {
      const group = new THREE.Group();
      const topBar = new THREE.Mesh(highBarrierGeom, highBarrierMat);
      topBar.position.y = 2.4;
      const laserMesh = new THREE.Mesh(laserGeom, laserMat);
      laserMesh.position.y = 1.2;
      // Add support posts
      const postGeom = new THREE.CylinderGeometry(0.1, 0.1, 2.4, 4);
      const postL = new THREE.Mesh(postGeom, highBarrierMat);
      postL.position.set(-1.5, 1.2, 0);
      const postR = new THREE.Mesh(postGeom, highBarrierMat);
      postR.position.set(1.5, 1.2, 0);

      group.add(topBar);
      group.add(laserMesh);
      group.add(postL);
      group.add(postR);
      group.visible = false;
      this.scene.add(group);
      this.obstaclePools.BARRIER_HIGH.push(group);
    }

    // Hover Car: Aerodynamic Cyber Wedge
    const carGeom = new THREE.BoxGeometry(2.4, 1.2, 4.8);
    const carMat = new THREE.MeshStandardMaterial({
      color: 0x5a00ff,
      emissive: 0x220077,
      roughness: 0.1,
      metalness: 0.7,
    });
    for (let i = 0; i < 10; i++) {
      const group = new THREE.Group();
      const body = new THREE.Mesh(carGeom, carMat);
      body.position.y = 0.6;
      // Add glowing neon wheels/thrusters
      const thrusterGeom = new THREE.CylinderGeometry(0.5, 0.5, 2.6, 8);
      thrusterGeom.rotateZ(Math.PI / 2);
      const thrusterMat = new THREE.MeshStandardMaterial({ color: 0xff00ff, emissive: 0xaa00aa });
      const thrusterF = new THREE.Mesh(thrusterGeom, thrusterMat);
      thrusterF.position.set(0, 0.2, 1.2);
      const thrusterB = new THREE.Mesh(thrusterGeom, thrusterMat);
      thrusterB.position.set(0, 0.2, -1.2);

      group.add(body);
      group.add(thrusterF);
      group.add(thrusterB);
      group.visible = false;
      this.scene.add(group);
      this.obstaclePools.HOVER_CAR.push(group);
    }

    // Drone: Floating Hexagonal Guard Drone
    const droneGeom = new THREE.OctahedronGeometry(0.7, 0);
    const droneMat = new THREE.MeshStandardMaterial({
      color: 0xff0055,
      emissive: 0xaa0033,
      metalness: 0.8,
      roughness: 0.2,
    });
    for (let i = 0; i < 15; i++) {
      const group = new THREE.Group();
      const body = new THREE.Mesh(droneGeom, droneMat);
      body.position.y = 3.2; // Hover height

      // Add horizontal glowing rings
      const ringGeom = new THREE.RingGeometry(0.9, 1.05, 8);
      ringGeom.rotateX(Math.PI / 2);
      const ringMat = new THREE.MeshBasicMaterial({ color: 0xff0055, side: THREE.DoubleSide });
      const ring = new THREE.Mesh(ringGeom, ringMat);
      ring.position.y = 3.2;

      group.add(body);
      group.add(ring);
      group.visible = false;
      this.scene.add(group);
      this.obstaclePools.DRONE.push(group);
    }

    // Ramp: Blue Cyber grid ramp for trick points & heights
    const rampGeom = new THREE.BoxGeometry(3.0, 1.6, 6.0);
    // Shearing the geometry to make it a ramp
    const posAttr = rampGeom.getAttribute('position');
    for (let i = 0; i < posAttr.count; i++) {
      const z = posAttr.getZ(i);
      const y = posAttr.getY(i);
      // Scale front vertices down to make ramp slope
      if (z < 0) {
        posAttr.setY(i, y - 0.79);
      }
    }
    rampGeom.computeVertexNormals();

    const rampMat = new THREE.MeshStandardMaterial({
      color: 0x00ccff,
      emissive: 0x003366,
      roughness: 0.3,
    });

    for (let i = 0; i < 5; i++) {
      const group = new THREE.Group();
      const mesh = new THREE.Mesh(rampGeom, rampMat);
      mesh.position.y = 0.8;
      // Add glowing neon arrows on ramp
      const arrowGeom = new THREE.BoxGeometry(1.2, 0.05, 1.2);
      const arrowMat = new THREE.MeshBasicMaterial({ color: 0x00ffcc });
      const arrow = new THREE.Mesh(arrowGeom, arrowMat);
      arrow.position.set(0, 1.62, 0);
      arrow.rotateX(-0.15); // Slope tilt

      group.add(mesh);
      group.add(arrow);
      group.visible = false;
      this.scene.add(group);
      this.obstaclePools.RAMP.push(group);
    }
  }

  private createPlayer() {
    this.playerGroup = new THREE.Group();
    this.playerGroup.position.set(0, 0, 0);
    this.scene.add(this.playerGroup);

    // Create Hoverboard (Sleek sci-fi wedge)
    const boardGeom = new THREE.BoxGeometry(1.2, 0.12, 2.6);
    const boardMat = new THREE.MeshStandardMaterial({
      color: new THREE.Color(this.activeSkin.color),
      emissive: new THREE.Color(this.activeSkin.color),
      emissiveIntensity: 1.8,
      roughness: 0.1,
      metalness: 0.9,
    });
    this.hoverboardMesh = new THREE.Mesh(boardGeom, boardMat);
    this.hoverboardMesh.position.y = 0.25;
    this.hoverboardMesh.castShadow = true;
    this.playerGroup.add(this.hoverboardMesh);

    // Create Rider (Geometric cybernetic human shape)
    // Body / Torso
    const bodyGeom = new THREE.BoxGeometry(0.6, 0.9, 0.4);
    const bodyMat = new THREE.MeshStandardMaterial({ color: 0x111116, roughness: 0.4, metalness: 0.8 });
    this.playerMesh = new THREE.Mesh(bodyGeom, bodyMat);
    this.playerMesh.position.set(0, 1.1, 0);
    this.playerMesh.castShadow = true;
    this.playerGroup.add(this.playerMesh);

    // Glowing Cyber Helmet
    const headGeom = new THREE.SphereGeometry(0.28, 12, 12);
    const visorMat = new THREE.MeshStandardMaterial({ color: 0xff00ff, emissive: 0xff00ff, emissiveIntensity: 1.5 });
    const head = new THREE.Mesh(headGeom, visorMat);
    head.position.set(0, 1.75, 0.05);
    this.playerGroup.add(head);

    // Glowing Limbs
    const limbGeom = new THREE.BoxGeometry(0.18, 0.7, 0.18);
    const limbMat = new THREE.MeshStandardMaterial({ color: 0x1a1a24 });

    const leftLeg = new THREE.Mesh(limbGeom, limbMat);
    leftLeg.position.set(-0.32, 0.65, 0.1);
    leftLeg.rotation.x = 0.2;
    this.playerGroup.add(leftLeg);

    const rightLeg = new THREE.Mesh(limbGeom, limbMat);
    rightLeg.position.set(0.32, 0.65, -0.1);
    rightLeg.rotation.x = -0.1;
    this.playerGroup.add(rightLeg);

    // Left Arm forward
    const leftArm = new THREE.Mesh(limbGeom, limbMat);
    leftArm.position.set(-0.45, 1.25, 0.25);
    leftArm.rotation.x = -0.5;
    this.playerGroup.add(leftArm);

    // Right Arm back
    const rightArm = new THREE.Mesh(limbGeom, limbMat);
    rightArm.position.set(0.45, 1.25, -0.2);
    rightArm.rotation.x = 0.3;
    this.playerGroup.add(rightArm);

    // Shield Bubble (initially invisible)
    const shieldGeom = new THREE.SphereGeometry(1.8, 16, 16);
    const shieldMat = new THREE.MeshBasicMaterial({
      color: 0x00ffcc,
      transparent: true,
      opacity: 0.35,
      wireframe: true,
    });
    this.shieldBubble = new THREE.Mesh(shieldGeom, shieldMat);
    this.shieldBubble.position.set(0, 1.0, 0);
    this.shieldBubble.visible = false;
    this.playerGroup.add(this.shieldBubble);

    // Create sleek Hoverboard Trail Particles
    this.particlePositions = new Float32Array(this.particleCount * 3);
    for (let i = 0; i < this.particleCount; i++) {
      this.particlePositions[i * 3] = 0;
      this.particlePositions[i * 3 + 1] = 0.2;
      this.particlePositions[i * 3 + 2] = 0;
    }
    this.particleGeometry = new THREE.BufferGeometry();
    this.particleGeometry.setAttribute('position', new THREE.BufferAttribute(this.particlePositions, 3));

    const particleMat = new THREE.PointsMaterial({
      color: 0x00ffff,
      size: 0.3,
      transparent: true,
      opacity: 0.8,
      blending: THREE.AdditiveBlending,
    });

    const points = new THREE.Points(this.particleGeometry, particleMat);
    this.scene.add(points);
    this.trailParticles.push(points);
  }

  private createSkyline() {
    // Generate static visual buildings in the distance to left and right of the highway
    const numBuildings = 35;
    const colors = [0x0d061a, 0x080c1d, 0x120420, 0x050811];

    for (let i = 0; i < numBuildings; i++) {
      const height = 25 + Math.random() * 55;
      const width = 8 + Math.random() * 12;
      const depth = 8 + Math.random() * 12;

      const buildGeom = new THREE.BoxGeometry(width, height, depth);
      const buildMat = new THREE.MeshStandardMaterial({
        color: colors[Math.floor(Math.random() * colors.length)],
        roughness: 0.7,
        metalness: 0.5,
      });

      const building = new THREE.Mesh(buildGeom, buildMat);

      // Distribute on left or right sides (X < -15 or X > 15)
      const side = Math.random() > 0.5 ? 1 : -1;
      const x = side * (18 + Math.random() * 25);
      const z = -(10 + Math.random() * 300);

      building.position.set(x, height / 2 - 2, z);
      this.scene.add(building);
      this.skylineBuildings.push(building);

      // Add a couple of glowing window bands or neon logo signs on top
      if (Math.random() > 0.4) {
        const logoGeom = new THREE.BoxGeometry(width + 0.2, 1.2, depth + 0.2);
        const neonColor = Math.random() > 0.5 ? 0xff00ff : 0x00ffff;
        const logoMat = new THREE.MeshBasicMaterial({ color: neonColor });
        const logo = new THREE.Mesh(logoGeom, logoMat);
        logo.position.set(0, height / 2 - 1.5, 0);
        building.add(logo);
      }
    }
  }

  private generateInitialRoads() {
    // Create road chunks sequentially to cover the path ahead
    this.currentChunkZ = 0;
    for (let i = 0; i < this.totalVisibleChunks; i++) {
      const isStartChunk = i < 2; // First chunks are safe/clear
      const chunk = this.createRoadChunk(this.currentChunkZ, isStartChunk);
      this.roadChunks.push(chunk);
      this.currentChunkZ -= this.chunkSize;
    }
  }

  private createRoadChunk(zPos: number, empty: boolean): RoadChunk {
    const chunkGroup = new THREE.Group();
    chunkGroup.position.set(0, 0, zPos);
    this.scene.add(chunkGroup);

    // 1. Dark Road Plane (Grid style)
    const roadGeom = new THREE.PlaneGeometry(12, this.chunkSize);
    roadGeom.rotateX(-Math.PI / 2); // Lay flat
    const roadMat = new THREE.MeshStandardMaterial({
      color: 0x06020c,
      roughness: 0.7,
      metalness: 0.9,
    });
    const road = new THREE.Mesh(roadGeom, roadMat);
    road.position.set(0, 0, -this.chunkSize / 2);
    road.receiveShadow = true;
    chunkGroup.add(road);

    // 2. Glowing Lane dividers
    const dividerGeom = new THREE.PlaneGeometry(0.12, this.chunkSize);
    dividerGeom.rotateX(-Math.PI / 2);
    const dividerMat = new THREE.MeshBasicMaterial({ color: 0x00ffff });

    // Left Lane divider
    const divL = new THREE.Mesh(dividerGeom, dividerMat);
    divL.position.set(-1.75, 0.01, -this.chunkSize / 2);
    chunkGroup.add(divL);

    // Right Lane divider
    const divR = new THREE.Mesh(dividerGeom, dividerMat);
    divR.position.set(1.75, 0.01, -this.chunkSize / 2);
    chunkGroup.add(divR);

    // Outer neon glowing road curbers (border rails)
    const railGeom = new THREE.BoxGeometry(0.3, 0.4, this.chunkSize);
    const railMat = new THREE.MeshStandardMaterial({ color: 0xff00ff, emissive: 0xaa00aa });

    const railL = new THREE.Mesh(railGeom, railMat);
    railL.position.set(-6, 0.2, -this.chunkSize / 2);
    chunkGroup.add(railL);

    const railR = new THREE.Mesh(railGeom, railMat);
    railR.position.set(6, 0.2, -this.chunkSize / 2);
    chunkGroup.add(railR);

    // 3. Spawning active entities (coins, obstacles) inside the chunk
    const entities: ActiveEntity[] = [];

    if (!empty) {
      // Choose layout pattern for this road chunk
      const pattern = Math.floor(Math.random() * 6);
      const lanes: Lane[] = [-1, 0, 1];

      if (pattern === 0) {
        // High Speed coins straight arc in center
        this.spawnCoinsArc(chunkGroup, 0, -10, -45, entities);
        this.spawnObstacleAt(chunkGroup, -1, -30, 'BARRIER_LOW', entities);
        this.spawnObstacleAt(chunkGroup, 1, -30, 'BARRIER_HIGH', entities);
      } else if (pattern === 1) {
        // Low Barrier left, Hover car center, Coin row right
        this.spawnObstacleAt(chunkGroup, -1, -20, 'BARRIER_LOW', entities);
        this.spawnObstacleAt(chunkGroup, 0, -35, 'HOVER_CAR', entities);
        this.spawnCoinsLine(chunkGroup, 1, -15, -45, 5, entities);
      } else if (pattern === 2) {
        // Ramp in center, flying coins!
        this.spawnObstacleAt(chunkGroup, 0, -25, 'RAMP', entities);
        this.spawnCoinsRampArc(chunkGroup, 0, -25, entities);
        // Barriers blocking sides
        this.spawnObstacleAt(chunkGroup, -1, -25, 'BARRIER_HIGH', entities);
        this.spawnObstacleAt(chunkGroup, 1, -25, 'BARRIER_HIGH', entities);
      } else if (pattern === 3) {
        // Symmetrical barriers, side lane escape
        this.spawnObstacleAt(chunkGroup, -1, -15, 'BARRIER_HIGH', entities);
        this.spawnObstacleAt(chunkGroup, 0, -15, 'BARRIER_HIGH', entities);
        this.spawnCoinsLine(chunkGroup, 1, -10, -30, 4, entities);

        this.spawnObstacleAt(chunkGroup, 1, -40, 'BARRIER_LOW', entities);
        this.spawnObstacleAt(chunkGroup, 0, -40, 'BARRIER_LOW', entities);
        this.spawnCoinsLine(chunkGroup, -1, -35, -55, 4, entities);
      } else if (pattern === 4) {
        // Hovering drone hazards and boosters
        this.spawnObstacleAt(chunkGroup, 0, -20, 'DRONE', entities);
        this.spawnObstacleAt(chunkGroup, -1, -35, 'DRONE', entities);
        this.spawnObstacleAt(chunkGroup, 1, -35, 'DRONE', entities);
        this.spawnPowerUpAt(chunkGroup, 0, -45, 'SPEED_BOOST', entities);
        this.spawnCoinsLine(chunkGroup, 0, -10, -30, 3, entities);
      } else if (pattern === 5) {
        // Shield powerup and zig zag barriers
        this.spawnPowerUpAt(chunkGroup, -1, -20, 'SHIELD', entities);
        this.spawnObstacleAt(chunkGroup, 0, -15, 'BARRIER_LOW', entities);
        this.spawnObstacleAt(chunkGroup, 1, -30, 'HOVER_CAR', entities);
        this.spawnObstacleAt(chunkGroup, -1, -45, 'BARRIER_HIGH', entities);
        this.spawnCoinsLine(chunkGroup, 0, -30, -55, 5, entities);
      }
    }

    return {
      mesh: chunkGroup,
      zPos,
      active: true,
      entities,
    };
  }

  private spawnCoinsLine(
    parent: THREE.Group,
    lane: Lane,
    zStart: number,
    zEnd: number,
    count: number,
    entities: ActiveEntity[]
  ) {
    const step = (zEnd - zStart) / Math.max(1, count - 1);
    for (let i = 0; i < count; i++) {
      const z = zStart + i * step;
      this.spawnCoinAt(parent, lane, z, 0.7, entities);
    }
  }

  private spawnCoinsArc(
    parent: THREE.Group,
    lane: Lane,
    zStart: number,
    zEnd: number,
    entities: ActiveEntity[]
  ) {
    const count = 6;
    const step = (zEnd - zStart) / (count - 1);
    for (let i = 0; i < count; i++) {
      const z = zStart + i * step;
      // Parabolic arc height
      const progress = i / (count - 1);
      const y = Math.sin(progress * Math.PI) * 2.5 + 0.7;
      this.spawnCoinAt(parent, lane, z, y, entities);
    }
  }

  private spawnCoinsRampArc(
    parent: THREE.Group,
    lane: Lane,
    rampZ: number,
    entities: ActiveEntity[]
  ) {
    // Spawn coins flying up after the ramp
    const count = 5;
    for (let i = 0; i < count; i++) {
      const z = rampZ - 3 - i * 3.5;
      const progress = i / (count - 1);
      const y = 2.4 + Math.sin(progress * Math.PI) * 1.5;
      this.spawnCoinAt(parent, lane, z, y, entities);
    }
  }

  private spawnCoinAt(
    parent: THREE.Group,
    lane: Lane,
    zRel: number,
    yPos: number,
    entities: ActiveEntity[]
  ) {
    // Get coin from pool
    const coin = this.coinPool[this.coinPoolIndex];
    this.coinPoolIndex = (this.coinPoolIndex + 1) % this.coinPool.length;

    coin.position.set(lane * this.laneDistance, yPos, zRel);
    coin.visible = true;
    parent.add(coin);

    entities.push({
      id: `coin_${Math.random()}`,
      mesh: coin,
      type: 'COIN',
      lane,
      zPos: zRel,
      yPos,
      collisionWidth: 1.2,
      collisionHeight: 1.2,
      collisionDepth: 1.2,
      active: true,
    });
  }

  private spawnObstacleAt(
    parent: THREE.Group,
    lane: Lane,
    zRel: number,
    type: 'BARRIER_LOW' | 'BARRIER_HIGH' | 'HOVER_CAR' | 'DRONE' | 'RAMP',
    entities: ActiveEntity[]
  ) {
    const pool = this.obstaclePools[type];
    const index = this.obstaclePoolIndexes[type];
    this.obstaclePoolIndexes[type] = (index + 1) % pool.length;

    const obstacle = pool[index];
    obstacle.position.set(lane * this.laneDistance, 0, zRel);
    obstacle.visible = true;
    parent.add(obstacle);

    let height = 1.0;
    let width = 2.5;
    let depth = 1.0;
    let yPos = 0;

    if (type === 'BARRIER_LOW') {
      height = 0.9;
      yPos = 0.45;
    } else if (type === 'BARRIER_HIGH') {
      height = 1.6;
      yPos = 1.6; // Collides only upper body
    } else if (type === 'HOVER_CAR') {
      height = 1.2;
      depth = 4.5;
      yPos = 0.6;
    } else if (type === 'DRONE') {
      height = 1.2;
      yPos = 3.2; // Collides with jump but not slide
    } else if (type === 'RAMP') {
      height = 1.6;
      depth = 6.0;
      yPos = 0.8;
    }

    entities.push({
      id: `obs_${Math.random()}`,
      mesh: obstacle,
      type: 'OBSTACLE',
      lane,
      zPos: zRel,
      yPos,
      collisionWidth: width,
      collisionHeight: height,
      collisionDepth: depth,
      active: true,
    });
  }

  private spawnPowerUpAt(
    parent: THREE.Group,
    lane: Lane,
    zRel: number,
    type: 'SPEED_BOOST' | 'SHIELD',
    entities: ActiveEntity[]
  ) {
    // Use an obstacle/glowing diamond shape for powerups
    const geom = new THREE.OctahedronGeometry(0.8, 0);
    const color = type === 'SPEED_BOOST' ? 0x00ff00 : 0x00ffff;
    const mat = new THREE.MeshStandardMaterial({ color, emissive: color, roughness: 0.2 });
    const mesh = new THREE.Mesh(geom, mat);
    mesh.position.set(lane * this.laneDistance, 1.0, zRel);

    parent.add(mesh);

    entities.push({
      id: `pwrup_${Math.random()}`,
      mesh,
      type,
      lane,
      zPos: zRel,
      yPos: 1.0,
      collisionWidth: 1.5,
      collisionHeight: 1.5,
      collisionDepth: 1.5,
      active: true,
    });
  }

  private setupInput() {
    // 1. Keyboard controls
    const handleKeyDown = (e: KeyboardEvent) => {
      this.activeKeys[e.key] = true;

      if (this.state !== GameState.RUNNING) return;

      if (e.key === 'ArrowLeft' || e.key === 'a' || e.key === 'A') {
        this.switchLane(-1);
      } else if (e.key === 'ArrowRight' || e.key === 'd' || e.key === 'D') {
        this.switchLane(1);
      } else if (e.key === 'ArrowUp' || e.key === 'w' || e.key === 'W' || e.key === ' ') {
        this.jump();
      } else if (e.key === 'ArrowDown' || e.key === 's' || e.key === 'S') {
        this.slide();
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      this.activeKeys[e.key] = false;
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    // 2. Touch/Mouse Swipe detection
    const handleTouchStart = (e: TouchEvent) => {
      this.touchStartX = e.touches[0].clientX;
      this.touchStartY = e.touches[0].clientY;
    };

    const handleTouchEnd = (e: TouchEvent) => {
      const diffX = e.changedTouches[0].clientX - this.touchStartX;
      const diffY = e.changedTouches[0].clientY - this.touchStartY;

      if (this.state !== GameState.RUNNING) return;

      // Classify gesture
      if (Math.abs(diffX) > Math.abs(diffY)) {
        // Horizontal swipe
        if (Math.abs(diffX) > this.minSwipeDistance) {
          if (diffX > 0) this.switchLane(1);
          else this.switchLane(-1);
        }
      } else {
        // Vertical swipe
        if (Math.abs(diffY) > this.minSwipeDistance) {
          if (diffY > 0) this.slide();
          else this.jump();
        }
      }
    };

    // Support mouse swipe
    let mouseIsDown = false;
    const handleMouseDown = (e: MouseEvent) => {
      mouseIsDown = true;
      this.touchStartX = e.clientX;
      this.touchStartY = e.clientY;
    };

    const handleMouseUp = (e: MouseEvent) => {
      if (!mouseIsDown) return;
      mouseIsDown = false;

      const diffX = e.clientX - this.touchStartX;
      const diffY = e.clientY - this.touchStartY;

      if (this.state !== GameState.RUNNING) return;

      if (Math.abs(diffX) > Math.abs(diffY)) {
        if (Math.abs(diffX) > this.minSwipeDistance) {
          if (diffX > 0) this.switchLane(1);
          else this.switchLane(-1);
        }
      } else {
        if (Math.abs(diffY) > this.minSwipeDistance) {
          if (diffY > 0) this.slide();
          else this.jump();
        }
      }
    };

    window.addEventListener('touchstart', handleTouchStart, { passive: true });
    window.addEventListener('touchend', handleTouchEnd, { passive: true });
    window.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mouseup', handleMouseUp);
  }

  private switchLane(dir: number) {
    const nextLane = (this.playerLane + dir) as Lane;
    if (nextLane >= -1 && nextLane <= 1) {
      gameAudio.playSwoosh();
      this.startLaneX = this.playerGroup.position.x;
      this.playerLane = nextLane;
      this.targetLane = nextLane;
      this.laneSwitchProgress = 0;
      this.onLog(`[SYSTEM] MovementSystem: Initiating lane transition to ${nextLane === -1 ? 'Left Lane' : nextLane === 1 ? 'Right Lane' : 'Center Lane'}`);
    }
  }

  private jump() {
    if (this.isJumping) return;
    // Cancel slide if jumping
    this.isSliding = false;

    this.isJumping = true;
    this.jumpProgress = 0;
    gameAudio.playJump();
    this.onLog('[INPUT] Command [JUMP] executed. Gravity force simulation: -9.81m/s²');
  }

  private slide() {
    if (this.isSliding) return;
    // Lower jump height if sliding
    this.isJumping = false;

    this.isSliding = true;
    this.slideProgress = 0;
    gameAudio.playSlide();
    this.onLog('[INPUT] Command [SLIDE] executed. Lowering collision bounds to 0.6 units');
  }

  public startGame() {
    this.state = GameState.RUNNING;
    this.stats.score = 0;
    this.stats.coins = 0;
    this.stats.distance = 0;
    this.stats.multiplier = 1;
    this.currentSpeed = this.baseSpeed;
    this.playerLane = 0;
    this.targetLane = 0;
    this.playerGroup.position.set(0, 0, 0);
    this.isJumping = false;
    this.isSliding = false;
    this.speedBoostActive = false;
    this.shieldActive = false;

    // Reset roads procedurally
    this.roadChunks.forEach((chunk) => {
      this.scene.remove(chunk.mesh);
    });
    this.roadChunks = [];
    this.generateInitialRoads();

    // Reset camera position
    this.camera.position.set(0, 5.5, 9);

    this.onStateChange(this.state);
    this.onStatsChange({ ...this.stats });

    gameAudio.startBGM();
    this.onLog('[SYSTEM] Neural Simulation Started. Uptime clock active.');
    this.onLog('[ENGINE] Procedural Generation: Initial road chunks spawned, object pools primed.');
  }

  public pauseGame() {
    if (this.state === GameState.RUNNING) {
      this.state = GameState.PAUSED;
      this.onStateChange(this.state);
      gameAudio.stopBGM();
    }
  }

  public resumeGame() {
    if (this.state === GameState.PAUSED) {
      this.state = GameState.RUNNING;
      this.onStateChange(this.state);
      gameAudio.startBGM();
    }
  }

  private crash() {
    this.state = GameState.GAMEOVER;
    gameAudio.playCrash();
    gameAudio.stopBGM();

    // Check high scores
    if (this.stats.score > this.stats.highScore) {
      this.stats.highScore = this.stats.score;
    }
    if (this.stats.coins > this.stats.highCoins) {
      this.stats.highCoins = this.stats.coins;
    }

    this.saveStats();
    this.onStateChange(this.state);
    this.onStatsChange({ ...this.stats });
  }

  private animate = () => {
    requestAnimationFrame(this.animate);

    const deltaTime = Math.min(this.clock.getDelta(), 0.1); // Cap deltaTime to prevent quantum tunnel tunneling on frame drop

    if (this.state === GameState.RUNNING) {
      this.update(deltaTime);
    }

    this.render();
  };

  private update(deltaTime: number) {
    // 1. Scale Speed
    let speed = this.currentSpeed;
    if (this.speedBoostActive) {
      speed *= 1.8;
      this.speedBoostTimer -= deltaTime;
      if (this.speedBoostTimer <= 0) {
        this.speedBoostActive = false;
      }
    }

    if (this.shieldActive) {
      this.shieldTimer -= deltaTime;
      if (this.shieldTimer <= 0) {
        this.shieldActive = false;
        this.shieldBubble.visible = false;
      }
    }

    // Boost base speed slowly as game progresses
    this.stats.distance += speed * deltaTime;
    this.currentSpeed = Math.min(this.maxSpeed, this.baseSpeed + (this.stats.distance / 120) * this.speedIncrement);

    // Update Score
    this.stats.score = Math.floor(this.stats.distance * 0.1 + this.stats.coins * 15) * this.stats.multiplier;
    this.onStatsChange({ ...this.stats });

    // 2. Snappy Lane Switching with Cubic-Bezier Easy Out Interpolation
    if (this.laneSwitchProgress < 1) {
      this.laneSwitchProgress += deltaTime / this.laneSwitchDuration;
      const t = Math.min(1, this.laneSwitchProgress);

      // cubic bezier curve calculation: y = 3t^2 - 2t^3 (Snappy smoothstep ease)
      const cubicBezier = t * t * (3 - 2 * t);

      const targetX = this.targetLane * this.laneDistance;
      this.playerX = THREE.MathUtils.lerp(this.startLaneX, targetX, cubicBezier);
      this.playerGroup.position.x = this.playerX;

      // Cool board tilt angle based on transition progress and direction
      const switchDir = this.targetLane - (this.startLaneX / this.laneDistance);
      this.hoverboardMesh.rotation.z = -switchDir * Math.sin(t * Math.PI) * 0.28;
      this.playerMesh.rotation.z = -switchDir * Math.sin(t * Math.PI) * 0.18;
    } else {
      this.hoverboardMesh.rotation.z = 0;
      this.playerMesh.rotation.z = 0;
    }

    // Move player continuously forward along Z axis
    this.playerGroup.position.z -= speed * deltaTime;

    // 3. Jump Parabolic Logic
    let playerY = 0;
    if (this.isJumping) {
      this.jumpProgress += deltaTime / this.jumpDuration;
      if (this.jumpProgress >= 1) {
        this.isJumping = false;
        playerY = 0;
        this.playerGroup.position.y = 0;
        this.hoverboardMesh.rotation.x = 0;
      } else {
        // Perfect sine parabola for arc jump
        playerY = Math.sin(this.jumpProgress * Math.PI) * this.jumpHeight;
        this.playerGroup.position.y = playerY;

        // Front flip rotation on high jump
        this.hoverboardMesh.rotation.x = -this.jumpProgress * Math.PI * 2;
      }
    }

    // 4. Slide Squish curve
    if (this.isSliding) {
      this.slideProgress += deltaTime / this.slideDuration;
      if (this.slideProgress >= 1) {
        this.isSliding = false;
        this.playerMesh.scale.set(1, 1, 1);
        this.playerMesh.position.y = 1.1;
      } else {
        // Shrink heights
        const progress = Math.sin(this.slideProgress * Math.PI);
        const scaleY = 1 - progress * 0.58;
        this.playerMesh.scale.set(1, scaleY, 1);
        this.playerMesh.position.y = 1.1 - progress * 0.35;
      }
    }

    // Update Shield indicator spin
    if (this.shieldActive) {
      this.shieldBubble.visible = true;
      this.shieldBubble.rotation.y += deltaTime * 2.5;
    }

    // 5. Camera follow tracking
    // Add dynamic camera shaking when ultra-fast
    const speedRatio = speed / this.baseSpeed;
    const cameraZOffset = 10 + (speedRatio - 1) * 2;
    this.camera.position.z = this.playerGroup.position.z + cameraZOffset;
    this.camera.position.x = THREE.MathUtils.lerp(this.camera.position.x, this.playerGroup.position.x * 0.8, 0.08);

    // Keep camera hovering slightly on jumps
    const targetCamY = 5.2 + playerY * 0.35;
    this.camera.position.y = THREE.MathUtils.lerp(this.camera.position.y, targetCamY, 0.1);

    // 6. Recycle road chunks seamlessly (Object Pooling)
    const fadeDistance = 45; // fall behind camera
    this.roadChunks.forEach((chunk) => {
      // If a road segment falls completely behind the camera view, recycle it to the front
      const chunkRelZ = chunk.mesh.position.z - this.camera.position.z;
      if (chunkRelZ > fadeDistance) {
        // Move chunk mesh ahead to the front
        this.currentChunkZ -= this.chunkSize;
        chunk.mesh.position.z = this.currentChunkZ;
        chunk.zPos = this.currentChunkZ;

        // Clean previous entities of the recycled chunk
        chunk.entities.forEach((entity) => {
          entity.mesh.visible = false;
          chunk.mesh.remove(entity.mesh);
          entity.active = false;
        });
        chunk.entities = [];

        // Regenerate entities randomly for the recycled chunk
        const pattern = Math.floor(Math.random() * 6);
        this.populateChunkEntities(chunk.mesh, pattern, chunk.entities);
        this.onLog(`[ENGINE] Seamless recycle: Road Chunk shifted to Z = ${this.currentChunkZ}. Pattern 0x0${pattern} injected.`);
      }
    });

    // 7. Coin Rotation
    this.coinPool.forEach((coin) => {
      if (coin.visible) {
        coin.rotation.y += deltaTime * 2.5;
      }
    });

    // 8. Collision System (AABB check)
    this.checkCollisions();

    // 9. Particles Trail update
    this.updateParticles(deltaTime);
  }

  private populateChunkEntities(parent: THREE.Group, pattern: number, entities: ActiveEntity[]) {
    // Reuses pooled objects to prevent high RAM/GC usage
    if (pattern === 0) {
      this.spawnCoinsArc(parent, 0, -10, -45, entities);
      this.spawnObstacleAt(parent, -1, -30, 'BARRIER_LOW', entities);
      this.spawnObstacleAt(parent, 1, -30, 'BARRIER_HIGH', entities);
    } else if (pattern === 1) {
      this.spawnObstacleAt(parent, -1, -20, 'BARRIER_LOW', entities);
      this.spawnObstacleAt(parent, 0, -35, 'HOVER_CAR', entities);
      this.spawnCoinsLine(parent, 1, -15, -45, 5, entities);
    } else if (pattern === 2) {
      this.spawnObstacleAt(parent, 0, -25, 'RAMP', entities);
      this.spawnCoinsRampArc(parent, 0, -25, entities);
      this.spawnObstacleAt(parent, -1, -25, 'BARRIER_HIGH', entities);
      this.spawnObstacleAt(parent, 1, -25, 'BARRIER_HIGH', entities);
    } else if (pattern === 3) {
      this.spawnObstacleAt(parent, -1, -15, 'BARRIER_HIGH', entities);
      this.spawnObstacleAt(parent, 0, -15, 'BARRIER_HIGH', entities);
      this.spawnCoinsLine(parent, 1, -10, -30, 4, entities);

      this.spawnObstacleAt(parent, 1, -40, 'BARRIER_LOW', entities);
      this.spawnObstacleAt(parent, 0, -40, 'BARRIER_LOW', entities);
      this.spawnCoinsLine(parent, -1, -35, -55, 4, entities);
    } else if (pattern === 4) {
      this.spawnObstacleAt(parent, 0, -20, 'DRONE', entities);
      this.spawnObstacleAt(parent, -1, -35, 'DRONE', entities);
      this.spawnObstacleAt(parent, 1, -35, 'DRONE', entities);
      this.spawnPowerUpAt(parent, 0, -45, 'SPEED_BOOST', entities);
      this.spawnCoinsLine(parent, 0, -10, -30, 3, entities);
    } else if (pattern === 5) {
      this.spawnPowerUpAt(parent, -1, -20, 'SHIELD', entities);
      this.spawnObstacleAt(parent, 0, -15, 'BARRIER_LOW', entities);
      this.spawnObstacleAt(parent, 1, -30, 'HOVER_CAR', entities);
      this.spawnObstacleAt(parent, -1, -45, 'BARRIER_HIGH', entities);
      this.spawnCoinsLine(parent, 0, -30, -55, 5, entities);
    }
  }

  private updateParticles(deltaTime: number) {
    const points = this.trailParticles[0];
    const posAttr = this.particleGeometry.getAttribute('position') as THREE.BufferAttribute;

    // Shift previous particles down the array
    for (let i = this.particleCount - 1; i > 0; i--) {
      posAttr.setX(i, posAttr.getX(i - 1));
      posAttr.setY(i, posAttr.getY(i - 1));
      posAttr.setZ(i, posAttr.getZ(i - 1));
    }

    // Place new particle at the board rear
    const px = this.playerGroup.position.x;
    const py = this.playerGroup.position.y + 0.25;
    const pz = this.playerGroup.position.z + 1.2;

    posAttr.setX(0, px + (Math.random() - 0.5) * 0.4);
    posAttr.setY(0, py + (Math.random() - 0.5) * 0.1);
    posAttr.setZ(0, pz);

    posAttr.needsUpdate = true;
  }

  private checkCollisions() {
    const px = this.playerGroup.position.x;
    const py = this.playerGroup.position.y;
    const pz = this.playerGroup.position.z;

    // Player AABB Bounding Box attributes
    const playerWidth = 1.0;
    // Slide lowers the height bounds
    const playerHeight = this.isSliding ? 0.6 : 1.8;
    const playerDepth = 2.4;

    // Iterate through active entities in currently visible chunks
    this.roadChunks.forEach((chunk) => {
      chunk.entities.forEach((entity) => {
        if (!entity.active || !entity.mesh.visible) return;

        // Convert the entity's relative chunk coordinates to absolute global coordinates
        const absX = entity.lane * this.laneDistance;
        const absY = entity.yPos;
        const absZ = chunk.zPos + entity.zPos; // Since chunk is at chunk.zPos and entity is at relative zPos

        // Calculate distance first for efficient broad-phase check
        const distZ = Math.abs(pz - absZ);
        if (distZ > 6.0) return; // Broad phase skip

        // AABB check
        const isColliding =
          Math.abs(px - absX) < (playerWidth + entity.collisionWidth) / 2 &&
          Math.abs((py + playerHeight / 2) - absY) < (playerHeight + entity.collisionHeight) / 2 &&
          Math.abs(pz - absZ) < (playerDepth + entity.collisionDepth) / 2;

        if (isColliding) {
          this.handleCollision(entity, chunk);
        }
      });
    });
  }

  private handleCollision(entity: ActiveEntity, chunk: RoadChunk) {
    if (entity.type === 'COIN') {
      entity.active = false;
      entity.mesh.visible = false;
      this.stats.coins += 1;
      this.stats.score += 15 * this.stats.multiplier;
      gameAudio.playCoin();
      this.onStatsChange({ ...this.stats });
      this.onLog(`[COLLISION] Gold Coin harvested. Core metrics: score +15, wallet total: ${this.stats.coins}`);
    } else if (entity.type === 'SPEED_BOOST') {
      entity.active = false;
      entity.mesh.visible = false;
      this.speedBoostActive = true;
      this.speedBoostTimer = 6.0; // 6 seconds super boost
      gameAudio.playPowerup();
      this.onLog('[COLLISION] Speed Boost offline -> ONLINE! Warp induction coils running hot for 6.0s.');
    } else if (entity.type === 'SHIELD') {
      entity.active = false;
      entity.mesh.visible = false;
      this.shieldActive = true;
      this.shieldTimer = 10.0; // 10 seconds shield
      gameAudio.playPowerup();
      this.onLog('[COLLISION] Deflector Shield online. Quantum protective bubble activated for 10.0s.');
    } else if (entity.type === 'OBSTACLE') {
      // Check if it's a Ramp! Player can glide up ramps safely

      if (entity.mesh === this.obstaclePools.RAMP[0] || entity.mesh === this.obstaclePools.RAMP[1] || entity.mesh === this.obstaclePools.RAMP[2] || entity.mesh === this.obstaclePools.RAMP[3] || entity.mesh === this.obstaclePools.RAMP[4]) {
        // Safe ramp interaction: set player Y to match the slope height
        const zDist = Math.abs(this.playerGroup.position.z - (chunk.zPos + entity.zPos));
        // Calculate Y based on position along ramp length (ramp is 6.0 deep)
        const t = Math.max(0, Math.min(1, (3.0 - (this.playerGroup.position.z - (chunk.zPos + entity.zPos))) / 6.0));
        const rampHeight = t * 1.6;
        if (!this.isJumping) {
          this.playerGroup.position.y = rampHeight;
        }
        if (!entity.hasLogTriggered) {
          entity.hasLogTriggered = true;
          this.onLog('[SYSTEM] Ramp Traversal: Slope vector locked. Dynamic gravity dampener active.');
        }
        return;
      }

      // If shield is active, we break the obstacle and lose shield
      if (this.shieldActive) {
        this.shieldActive = false;
        this.shieldBubble.visible = false;
        entity.active = false;
        entity.mesh.visible = false;
        gameAudio.playCrash(); // Short explosion fx
        this.onLog('[PHYSICS] Critical Impact! Deflector Shield absorbed kinetic force and collapsed.');
        return;
      }

      // Collided! GameOver
      this.onLog('[PHYSICS] Critical Collision! Frame stress limits exceeded. Severing neural link...');
      this.crash();
    }
  }

  private render() {
    this.renderer.render(this.scene, this.camera);
  }

  public resize(width: number, height: number) {
    if (this.camera && this.renderer) {
      this.camera.aspect = width / height;
      this.camera.updateProjectionMatrix();
      this.renderer.setSize(width, height);
    }
  }

  public cleanUp() {
    gameAudio.stopBGM();
    window.removeEventListener('keydown', () => {});
    window.removeEventListener('keyup', () => {});
    window.removeEventListener('touchstart', () => {});
    window.removeEventListener('touchend', () => {});
    window.removeEventListener('mousedown', () => {});
    window.removeEventListener('mouseup', () => {});
  }
}

export const gameEngine = new GameEngine();
