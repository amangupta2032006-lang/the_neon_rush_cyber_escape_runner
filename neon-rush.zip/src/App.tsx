/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect, useRef, useState } from 'react';
import { GameState, PlayerStats } from './types';
import { gameEngine } from './engine/GameEngine';
import GameUI from './components/GameUI';
import { 
  Folder, FileText, Terminal, Settings, Cpu, Layers, Activity, 
  FileCode, Play, Pause, RefreshCw, Eye, Sliders, Server, Zap, Shield, HardDrive
} from 'lucide-react';

export default function App() {
  const containerRef = useRef<HTMLDivElement>(null);
  const logsEndRef = useRef<HTMLDivElement>(null);
  const lastFrameTimeRef = useRef<number>(performance.now());
  
  const [gameState, setGameState] = useState<GameState>(GameState.MENU);
  const [stats, setStats] = useState<PlayerStats>({
    score: 0,
    coins: 0,
    multiplier: 1,
    distance: 0,
    highScore: 0,
    highCoins: 0,
  });

  // Uptime tracker
  const [startTime] = useState<number>(Date.now());
  const [uptime, setUptime] = useState<string>('00:00.00');

  // Logs state
  const [logs, setLogs] = useState<string[]>([]);
  const [activeLogTab, setActiveLogTab] = useState<'DEBUG_CON' | 'RAPIER_STDOUT' | 'VITE_STDOUT'>('DEBUG_CON');

  // File tree mock state
  const [selectedFile, setSelectedFile] = useState<string>('GameEngine.ts');

  // Frame inspection variables
  const [inspector, setInspector] = useState({
    speed: 26,
    lane: 0,
    targetLane: 0,
    isJumping: false,
    isSliding: false,
    speedBoostActive: false,
    speedBoostTimer: 0,
    shieldActive: false,
    shieldTimer: 0,
    fps: 60,
  });

  const [latencyHistory, setLatencyHistory] = useState<number[]>([16.6, 16.2, 16.8, 15.9, 16.4, 16.7, 17.1, 15.8, 16.2, 16.6, 16.1, 16.9, 16.3, 16.5, 16.0, 16.4, 16.8, 16.2, 16.6, 17.2, 15.9, 16.3, 16.7, 16.1, 16.9, 16.2, 16.6, 15.8, 16.4, 16.7, 16.1, 16.8, 16.3, 16.5, 16.0, 16.4, 16.8, 16.2, 16.6, 17.0]);

  // Utility to append logs with pristine timestamps
  const addLog = (message: string) => {
    const now = new Date();
    const hrs = String(now.getHours()).padStart(2, '0');
    const mins = String(now.getMinutes()).padStart(2, '0');
    const secs = String(now.getSeconds()).padStart(2, '0');
    const ms = String(now.getMilliseconds()).padStart(3, '0');
    const timestamp = `${hrs}:${mins}:${secs}.${ms}`;
    setLogs((prev) => [...prev.slice(-99), `[${timestamp}] ${message}`]);
  };

  useEffect(() => {
    // Prime initial log system logs
    addLog('[SYSTEM] Neural Core booting... Link Status: OK');
    addLog('[SYSTEM] RapierJS v0.11.2 (Deterministic WASM) active.');
    addLog('[ENGINE] WebGLRenderer initialized with standard devicePixelRatio.');
    addLog('[AUDIO] FM Synthesizer sound board fully synchronized.');
  }, []);

  useEffect(() => {
    if (!containerRef.current) return;

    // Initialize Game Engine with reactive logs and stats
    gameEngine.init(
      containerRef.current,
      (state) => setGameState(state),
      (currentStats) => setStats(currentStats),
      (msg) => addLog(msg)
    );

    // Sync initial state and stats
    setGameState(gameEngine.state);
    setStats({ ...gameEngine.stats });

    // Handle resizing dynamically using ResizeObserver for precise container alignment
    const resizeObserver = new ResizeObserver((entries) => {
      for (let entry of entries) {
        const { width, height } = entry.contentRect;
        gameEngine.resize(width, height);
      }
    });

    if (containerRef.current) {
      resizeObserver.observe(containerRef.current);
    }

    // Backup window resize listener
    const handleWindowResize = () => {
      if (containerRef.current) {
        gameEngine.resize(containerRef.current.clientWidth, containerRef.current.clientHeight);
      }
    };
    window.addEventListener('resize', handleWindowResize);

    return () => {
      resizeObserver.disconnect();
      window.removeEventListener('resize', handleWindowResize);
      gameEngine.cleanUp();
    };
  }, []);

  // Sync physics / engine metrics and FPS in a high-frequency tick loop
  useEffect(() => {
    let lastTime = performance.now();
    let frameCount = 0;
    let fpsVal = 60;
    let animationFrameId: number;

    const tick = () => {
      frameCount++;
      const now = performance.now();
      
      // Calculate real-time FPS
      if (now - lastTime >= 1000) {
        fpsVal = Math.round((frameCount * 1000) / (now - lastTime));
        frameCount = 0;
        lastTime = now;
      }

      // Calculate exact frame latency
      const frameLatency = now - lastFrameTimeRef.current;
      lastFrameTimeRef.current = now;

      setLatencyHistory((prev) => {
        const next = [...prev.slice(-39), frameLatency];
        return next;
      });

      // Update inspector state from the live gameEngine properties
      setInspector({
        speed: gameEngine.currentSpeed || 26,
        lane: gameEngine.playerLane ?? 0,
        targetLane: gameEngine.targetLane ?? 0,
        isJumping: gameEngine.isJumping ?? false,
        isSliding: gameEngine.isSliding ?? false,
        speedBoostActive: gameEngine.speedBoostActive ?? false,
        speedBoostTimer: gameEngine.speedBoostTimer ?? 0,
        shieldActive: gameEngine.shieldActive ?? false,
        shieldTimer: gameEngine.shieldTimer ?? 0,
        fps: fpsVal,
      });

      // Calculate uptime formatted as MM:SS.CC (centiseconds)
      const elapsed = Date.now() - startTime;
      const mins = String(Math.floor(elapsed / 60000)).padStart(2, '0');
      const secs = String(Math.floor((elapsed % 60000) / 1000)).padStart(2, '0');
      const cents = String(Math.floor((elapsed % 1000) / 10)).padStart(2, '0');
      setUptime(`${mins}:${secs}.${cents}`);

      animationFrameId = requestAnimationFrame(tick);
    };

    animationFrameId = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(animationFrameId);
  }, [startTime]);

  // Scroll to bottom of logs on tab updates and new logs
  useEffect(() => {
    if (logsEndRef.current) {
      logsEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [logs, activeLogTab]);

  return (
    <div className="bg-[#050506] text-[#e0e0e0] w-screen h-screen flex flex-col font-mono overflow-hidden select-none">
      
      {/* HEADER BAR */}
      <header className="h-12 border-b border-[#1c1c24] flex items-center justify-between px-6 bg-[#0c0c0e] shrink-0 text-xs">
        <div className="flex items-center space-x-3">
          {/* Pulsing indicator of core engine state */}
          <span className="relative flex h-2 w-2">
            <span className={`animate-ping absolute inline-flex h-full w-full rounded-full ${gameState === GameState.RUNNING ? 'bg-emerald-400' : 'bg-rose-400'} opacity-75`}></span>
            <span className={`relative inline-flex rounded-full h-2 w-2 ${gameState === GameState.RUNNING ? 'bg-emerald-500' : 'bg-rose-500'}`}></span>
          </span>
          <h1 className="font-bold tracking-widest text-slate-100 uppercase flex items-center gap-2">
            <span>NEON_RUSH</span>
            <span className="text-slate-600 font-normal">v1.12_DEB_LOG</span>
          </h1>
        </div>
        
        {/* Workspace details */}
        <div className="hidden md:flex items-center space-x-6 text-[11px] text-slate-500">
          <div className="flex items-center gap-1.5">
            <Server className="w-3.5 h-3.5 text-slate-600" />
            <span>IP: <span className="text-slate-300">127.0.0.1</span></span>
          </div>
          <div className="flex items-center gap-1.5">
            <Cpu className="w-3.5 h-3.5 text-slate-600" />
            <span>ENGINE: <span className="text-slate-300">THREE.JS v158</span></span>
          </div>
          <div className="flex items-center gap-1.5">
            <HardDrive className="w-3.5 h-3.5 text-slate-600" />
            <span>BRANCH: <span className="text-indigo-400">master</span></span>
          </div>
        </div>

        {/* Live Uptime metric */}
        <div className="text-[11px] text-slate-400 bg-[#16161b] px-3 py-1 border border-[#23232c] rounded flex items-center gap-2">
          <span className="text-slate-500 uppercase tracking-widest text-[9px]">Uptime:</span>
          <span className="font-mono text-[#00ffff] font-semibold">{uptime}</span>
        </div>
      </header>

      {/* CORE CONTENT LAYOUT */}
      <div className="flex-1 flex overflow-hidden min-h-0">
        
        {/* LEFT SIDEBAR - FILE NAVIGATION */}
        <aside className="hidden lg:flex w-64 border-r border-[#1c1c24] bg-[#08080a] flex-col overflow-hidden shrink-0">
          
          {/* Header */}
          <div className="p-3 border-b border-[#1c1c24] bg-[#0c0c0e] flex items-center justify-between text-[11px] text-slate-400">
            <span className="font-semibold uppercase tracking-wider text-slate-300">Workspace Files</span>
            <span className="text-[10px] text-slate-600">WORKSPACE_01</span>
          </div>

          {/* Directory Hierarchy */}
          <div className="flex-1 p-3 overflow-y-auto space-y-3 text-[11px]">
            <div className="space-y-1.5">
              <div className="flex items-center space-x-1.5 text-slate-400">
                <Folder className="w-4 h-4 text-amber-500" />
                <span className="font-bold">project_neon_rush</span>
              </div>
              
              <div className="pl-4 space-y-1.5">
                <div className="flex items-center space-x-1.5 text-slate-400">
                  <Folder className="w-4 h-4 text-sky-400" />
                  <span>src</span>
                </div>

                <div className="pl-4 space-y-1">
                  <div className="flex items-center space-x-1.5 text-slate-500">
                    <Folder className="w-3.5 h-3.5 text-violet-400" />
                    <span>engine</span>
                  </div>
                  
                  <div className="pl-4 space-y-1">
                    <button 
                      onClick={() => setSelectedFile('GameEngine.ts')}
                      className={`w-full flex items-center justify-between px-2 py-0.5 rounded transition-all text-left ${selectedFile === 'GameEngine.ts' ? 'bg-indigo-950/40 text-[#00ffff] border-l-2 border-[#00ffff] pl-1.5' : 'hover:bg-slate-900/40 text-slate-400'}`}
                    >
                      <span className="flex items-center gap-1.5 truncate">
                        <FileCode className="w-3.5 h-3.5 shrink-0" />
                        <span className="truncate">GameEngine.ts</span>
                      </span>
                      {selectedFile === 'GameEngine.ts' && (
                        <span className="text-[8px] px-1 bg-[#00ffff]/20 text-[#00ffff] font-mono rounded">RUN</span>
                      )}
                    </button>
                    <button 
                      onClick={() => setSelectedFile('AudioEngine.ts')}
                      className={`w-full flex items-center justify-between px-2 py-0.5 rounded transition-all text-left ${selectedFile === 'AudioEngine.ts' ? 'bg-indigo-950/40 text-[#00ffff] border-l-2 border-[#00ffff] pl-1.5' : 'hover:bg-slate-900/40 text-slate-400'}`}
                    >
                      <span className="flex items-center gap-1.5 truncate">
                        <FileCode className="w-3.5 h-3.5 shrink-0" />
                        <span className="truncate">AudioEngine.ts</span>
                      </span>
                    </button>
                  </div>

                  <div className="flex items-center space-x-1.5 text-slate-500">
                    <Folder className="w-3.5 h-3.5 text-teal-400" />
                    <span>components</span>
                  </div>

                  <div className="pl-4 space-y-1">
                    <button 
                      onClick={() => setSelectedFile('GameUI.tsx')}
                      className={`w-full flex items-center justify-between px-2 py-0.5 rounded transition-all text-left ${selectedFile === 'GameUI.tsx' ? 'bg-indigo-950/40 text-[#00ffff] border-l-2 border-[#00ffff] pl-1.5' : 'hover:bg-slate-900/40 text-slate-400'}`}
                    >
                      <span className="flex items-center gap-1.5 truncate">
                        <FileCode className="w-3.5 h-3.5 shrink-0" />
                        <span className="truncate">GameUI.tsx</span>
                      </span>
                    </button>
                    <button 
                      onClick={() => setSelectedFile('App.tsx')}
                      className={`w-full flex items-center justify-between px-2 py-0.5 rounded transition-all text-left ${selectedFile === 'App.tsx' ? 'bg-indigo-950/40 text-[#00ffff] border-l-2 border-[#00ffff] pl-1.5' : 'hover:bg-slate-900/40 text-slate-400'}`}
                    >
                      <span className="flex items-center gap-1.5 truncate">
                        <FileCode className="w-3.5 h-3.5 shrink-0" />
                        <span className="truncate">App.tsx</span>
                      </span>
                    </button>
                  </div>

                  <button 
                    onClick={() => setSelectedFile('types.ts')}
                    className={`w-full flex items-center px-2 py-0.5 pl-6 rounded transition-all text-left ${selectedFile === 'types.ts' ? 'bg-indigo-950/40 text-[#00ffff] border-l-2 border-[#00ffff] pl-5' : 'hover:bg-slate-900/40 text-slate-400'}`}
                  >
                    <FileText className="w-3.5 h-3.5 mr-1.5 shrink-0" />
                    <span className="truncate">types.ts</span>
                  </button>
                </div>
              </div>
            </div>

            <div className="space-y-1">
              <div className="flex items-center space-x-1.5 text-slate-500">
                <Folder className="w-3.5 h-3.5 text-slate-600" />
                <span>config</span>
              </div>
              <div className="pl-4 space-y-1">
                <button 
                  onClick={() => setSelectedFile('package.json')}
                  className={`w-full flex items-center px-2 py-0.5 rounded transition-all text-left ${selectedFile === 'package.json' ? 'bg-indigo-950/40 text-[#00ffff] border-l-2 border-[#00ffff] pl-1.5' : 'hover:bg-slate-900/40 text-slate-500'}`}
                >
                  <FileText className="w-3.5 h-3.5 mr-1.5 shrink-0" />
                  <span>package.json</span>
                </button>
                <button 
                  onClick={() => setSelectedFile('vite.config.ts')}
                  className={`w-full flex items-center px-2 py-0.5 rounded transition-all text-left ${selectedFile === 'vite.config.ts' ? 'bg-indigo-950/40 text-[#00ffff] border-l-2 border-[#00ffff] pl-1.5' : 'hover:bg-slate-900/40 text-slate-500'}`}
                >
                  <FileText className="w-3.5 h-3.5 mr-1.5 shrink-0" />
                  <span>vite.config.ts</span>
                </button>
              </div>
            </div>
          </div>

          {/* Quick Stats Summary Panel */}
          <div className="p-3 border-t border-[#1c1c24] bg-[#0c0c0e] text-[10px] space-y-1 text-slate-500">
            <div className="flex justify-between">
              <span>ACTIVE MODEL:</span>
              <span className="text-slate-300">GEMINI_2.5_FLASH</span>
            </div>
            <div className="flex justify-between">
              <span>PHYSICS SOLVER:</span>
              <span className="text-pink-500 font-bold">RAPIER</span>
            </div>
            <div className="flex justify-between">
              <span>PERSISTENCE:</span>
              <span className="text-slate-300">LOCAL_STORAGE</span>
            </div>
          </div>
        </aside>

        {/* CENTRAL AREA - VISUAL VIEWPORT & BOTTOM CONSOLE */}
        <main className="flex-1 bg-[#020203] relative flex flex-col min-w-0">
          
          {/* Header Tab of active file editor */}
          <div className="h-9 border-b border-[#1c1c24] bg-[#0c0c0e] flex items-center px-4 justify-between shrink-0 text-xs text-slate-400">
            <div className="flex items-center space-x-2">
              <span className="text-[#00ffff]">⚡</span>
              <span className="font-semibold text-slate-200">ACTIVE_VIEWPORT://3D_SIMULATION_STAGE</span>
            </div>
            <div className="text-[10px] text-slate-600 uppercase font-mono tracking-widest">
              Camera Field Of View: 60deg
            </div>
          </div>

          {/* THE 3D VIEWPORT CONTAINER */}
          <div className="flex-1 relative w-full h-full min-h-0 bg-black overflow-hidden flex flex-col justify-between">
            
            {/* Standard Three.js WebGL canvas */}
            <div 
              ref={containerRef} 
              className="w-full h-full absolute inset-0 z-0 select-none cursor-grab active:cursor-grabbing" 
            />

            {/* Retro Sci-Fi scanlines & Ambient vignette overlay for high-end aesthetic inside the stage */}
            <div className="pointer-events-none absolute inset-0 z-20 bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.18)_50%)] bg-[size:100%_4px] opacity-25 mix-blend-overlay" />
            <div className="pointer-events-none absolute inset-0 z-20 bg-radial-gradient from-transparent via-[#030008]/20 to-[#020005]/60" />

            {/* Cybernetic HUD Interface Overlay (React-based overlay) */}
            <GameUI
              gameState={gameState}
              stats={stats}
              onStartGame={() => gameEngine.startGame()}
            />
          </div>

          {/* BOTTOM TERMINAL PANEL */}
          <section className="h-48 border-t border-[#1c1c24] bg-[#0c0c0e] flex flex-col shrink-0 overflow-hidden">
            
            {/* Tab header */}
            <div className="h-8 border-b border-[#1c1c24] flex items-center justify-between px-4 bg-[#0a0a0c] text-xs">
              <div className="flex space-x-2">
                <button 
                  onClick={() => setActiveLogTab('DEBUG_CON')}
                  className={`px-3 py-1 transition-all rounded-t-sm ${activeLogTab === 'DEBUG_CON' ? 'bg-[#121216] border-b-2 border-[#00ffff] text-[#00ffff] font-semibold' : 'text-slate-500 hover:text-slate-300'}`}
                >
                  <span className="flex items-center gap-1.5">
                    <Terminal className="w-3.5 h-3.5" />
                    DEBUG_CONSOLE
                  </span>
                </button>
                <button 
                  onClick={() => setActiveLogTab('RAPIER_STDOUT')}
                  className={`px-3 py-1 transition-all rounded-t-sm ${activeLogTab === 'RAPIER_STDOUT' ? 'bg-[#121216] border-b-2 border-pink-500 text-pink-400' : 'text-slate-500 hover:text-slate-300'}`}
                >
                  <span className="flex items-center gap-1.5">
                    <Cpu className="w-3.5 h-3.5" />
                    RAPIER_STDOUT
                  </span>
                </button>
                <button 
                  onClick={() => setActiveLogTab('VITE_STDOUT')}
                  className={`px-3 py-1 transition-all rounded-t-sm ${activeLogTab === 'VITE_STDOUT' ? 'bg-[#121216] border-b-2 border-indigo-500 text-indigo-400' : 'text-slate-500 hover:text-slate-300'}`}
                >
                  <span className="flex items-center gap-1.5">
                    <Server className="w-3.5 h-3.5" />
                    VITE_STDOUT
                  </span>
                </button>
              </div>

              <div className="text-[10px] text-slate-600 font-mono flex items-center gap-3">
                <span>Total Stream Size: {logs.length} lines</span>
                <button 
                  onClick={() => setLogs([])}
                  className="hover:text-rose-400 transition-all font-semibold uppercase flex items-center gap-1 bg-[#15151b] px-2 py-0.5 border border-[#22222d] rounded"
                >
                  Clear Buffer
                </button>
              </div>
            </div>

            {/* Scrollable logs contents */}
            <div className="flex-1 p-3 font-mono text-[10px] md:text-[11px] overflow-y-auto space-y-1 bg-[#060608]">
              {activeLogTab === 'DEBUG_CON' && (
                <>
                  {logs.length === 0 ? (
                    <div className="text-slate-600 italic">No log outputs recorded yet. Press Start to initiate gameplay.</div>
                  ) : (
                    logs.map((log, idx) => {
                      let textClass = 'text-slate-400';
                      if (log.includes('[COLLISION]')) textClass = 'text-[#00ffff]';
                      else if (log.includes('[SYSTEM]')) textClass = 'text-indigo-400';
                      else if (log.includes('[ENGINE]')) textClass = 'text-amber-400';
                      else if (log.includes('[PHYSICS]')) textClass = 'text-rose-400 font-bold';
                      else if (log.includes('[INPUT]')) textClass = 'text-purple-400';

                      return (
                        <div key={idx} className={`${textClass} leading-tight`}>
                          {log}
                        </div>
                      );
                    })
                  )}
                  <div ref={logsEndRef} />
                </>
              )}

              {activeLogTab === 'RAPIER_STDOUT' && (
                <div className="text-pink-400/95 space-y-1">
                  <div>[RAPIER] Loaded WebAssembly solver binary successfully (1.42MB).</div>
                  <div>[RAPIER] Continuous Collision Detection (CCD) enabled on rigid player mesh.</div>
                  <div>[RAPIER] Active rigid controllers initialized: 1</div>
                  <div>[RAPIER] Active dynamic environment colliders indexed in pool: 120</div>
                  <div>[RAPIER] Broad-phase sweep-and-prune bounding box algorithm: ACTIVE</div>
                  <div>[RAPIER] Solver iterations configured: 4 (Position) | 1 (Velocity)</div>
                  <div>[RAPIER] Gravity vector initialized: [0.00, -9.81, 0.00] m/s²</div>
                  <div>[RAPIER] Substepping loop initialized successfully. No time-step drifts detected.</div>
                </div>
              )}

              {activeLogTab === 'VITE_STDOUT' && (
                <div className="text-indigo-400/95 space-y-1">
                  <div className="text-indigo-300 font-bold">VITE v6.2.3  ready in 425 ms</div>
                  <div className="pl-4">➜  Local:   <span className="underline">http://localhost:3000/</span></div>
                  <div className="pl-4 text-slate-500">➜  Network: use --host to expose</div>
                  <div>[vite] hot module replacement disabled by client request.</div>
                  <div>[vite] client joined workspace container session #22e846</div>
                  <div>[vite] compile entry point: /src/main.tsx...</div>
                  <div>[vite] bundle generated in 118ms. No warnings.</div>
                </div>
              )}
            </div>
          </section>
        </main>

        {/* RIGHT SIDEBAR - PHYSICS INSPECTOR */}
        <aside className="hidden md:flex w-72 border-l border-[#1c1c24] bg-[#08080a] flex-col overflow-y-auto shrink-0">
          
          {/* Header */}
          <div className="p-3 border-b border-[#1c1c24] bg-[#0c0c0e] flex items-center justify-between text-[11px] text-slate-400 shrink-0">
            <span className="font-semibold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
              <Activity className="w-3.5 h-3.5 text-pink-500" />
              Physics Inspector
            </span>
            <span className="font-mono text-[9px] text-[#00ffff] bg-[#00ffff]/10 px-1.5 py-0.5 rounded">{inspector.fps} FPS</span>
          </div>

          {/* Metrics Sections */}
          <div className="flex-1 p-3 space-y-4 text-[11px]">
            
            {/* Deterministic Setup Stats */}
            <div className="space-y-2">
              <div className="text-[10px] text-slate-500 uppercase tracking-widest font-bold">Solver Variables</div>
              <div className="bg-[#0c0c0e] border border-[#1c1c24] p-2 rounded space-y-1.5 font-mono text-[10px]">
                <div className="flex justify-between">
                  <span className="text-slate-500">TIME STEP:</span>
                  <span className="text-slate-300">0.016s (60Hz)</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">CCD SYSTEM:</span>
                  <span className="text-slate-300 font-semibold text-teal-400">ENABLED</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">SOLVER_ITERS:</span>
                  <span className="text-slate-300">4 iterations</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">FRICTION:</span>
                  <span className="text-slate-300">0.05 (Air Glide)</span>
                </div>
              </div>
            </div>

            {/* Live Controller Physics States */}
            <div className="space-y-2">
              <div className="text-[10px] text-slate-500 uppercase tracking-widest font-bold">Rigid Controller State</div>
              <div className="bg-[#0c0c0e] border border-[#1c1c24] p-2.5 rounded space-y-2 font-mono text-[10px]">
                
                {/* Velocity */}
                <div>
                  <div className="flex justify-between text-[10px] mb-1">
                    <span className="text-slate-500">LINEAR VELOCITY (Z):</span>
                    <span className="text-[#00ffff] font-semibold">{inspector.speed.toFixed(2)} m/s</span>
                  </div>
                  <div className="w-full bg-slate-950 rounded-full h-1.5 overflow-hidden">
                    <div 
                      className="bg-gradient-to-r from-teal-500 to-[#00ffff] h-1.5 rounded-full transition-all duration-100" 
                      style={{ width: `${Math.min(100, (inspector.speed / 55) * 100)}%` }}
                    />
                  </div>
                </div>

                {/* Lane state */}
                <div className="grid grid-cols-2 gap-2 pt-1 border-t border-[#1c1c24]">
                  <div>
                    <span className="text-slate-500 block text-[9px]">ACTIVE LANE:</span>
                    <span className={`font-semibold ${inspector.lane === -1 ? 'text-indigo-400' : inspector.lane === 1 ? 'text-pink-400' : 'text-slate-300'}`}>
                      {inspector.lane === -1 ? 'LEFT (-1)' : inspector.lane === 1 ? 'RIGHT (1)' : 'CENTER (0)'}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[9px]">TARGET LANE:</span>
                    <span className="text-slate-400">{inspector.targetLane}</span>
                  </div>
                </div>

                {/* Grounded & jumping */}
                <div className="grid grid-cols-2 gap-2 pt-1.5 border-t border-[#1c1c24]">
                  <div>
                    <span className="text-slate-500 block text-[9px]">ALTITUDE STATE:</span>
                    <span className={`font-semibold ${inspector.isJumping ? 'text-amber-400' : 'text-teal-400'}`}>
                      {inspector.isJumping ? 'AIRBORNE' : 'GROUNDED'}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[9px]">FORM PROFILE:</span>
                    <span className={`font-semibold ${inspector.isSliding ? 'text-purple-400' : 'text-slate-300'}`}>
                      {inspector.isSliding ? 'SLIDING (LOW)' : 'STANDARD'}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Buffers and Powerups Status */}
            <div className="space-y-2">
              <div className="text-[10px] text-slate-500 uppercase tracking-widest font-bold">Linked Micro Buffers</div>
              <div className="bg-[#0c0c0e] border border-[#1c1c24] p-2.5 rounded space-y-2 text-[10px]">
                
                {/* Shield buffer */}
                <div>
                  <div className="flex justify-between items-center text-[10px] mb-1">
                    <span className="flex items-center gap-1 text-slate-500">
                      <Shield className={`w-3.5 h-3.5 ${inspector.shieldActive ? 'text-[#00ffff] animate-pulse' : 'text-slate-600'}`} />
                      DEFLECTOR GRID:
                    </span>
                    <span className={inspector.shieldActive ? 'text-[#00ffff] font-bold' : 'text-slate-600'}>
                      {inspector.shieldActive ? `${inspector.shieldTimer.toFixed(1)}s` : 'OFF'}
                    </span>
                  </div>
                  <div className="w-full bg-slate-950 rounded-full h-1 overflow-hidden">
                    <div 
                      className="bg-[#00ffff] h-1 rounded-full transition-all duration-100" 
                      style={{ width: inspector.shieldActive ? `${(inspector.shieldTimer / 10.0) * 100}%` : '0%' }}
                    />
                  </div>
                </div>

                {/* Speed booster buffer */}
                <div className="pt-1.5 border-t border-[#1c1c24]">
                  <div className="flex justify-between items-center text-[10px] mb-1">
                    <span className="flex items-center gap-1 text-slate-500">
                      <Zap className={`w-3.5 h-3.5 ${inspector.speedBoostActive ? 'text-green-400 animate-pulse' : 'text-slate-600'}`} />
                      WARP BOOSTER:
                    </span>
                    <span className={inspector.speedBoostActive ? 'text-green-400 font-bold' : 'text-slate-600'}>
                      {inspector.speedBoostActive ? `${inspector.speedBoostTimer.toFixed(1)}s` : 'OFF'}
                    </span>
                  </div>
                  <div className="w-full bg-slate-950 rounded-full h-1 overflow-hidden">
                    <div 
                      className="bg-green-500 h-1 rounded-full transition-all duration-100" 
                      style={{ width: inspector.speedBoostActive ? `${(inspector.speedBoostTimer / 6.0) * 100}%` : '0%' }}
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* REAL-TIME LATENCY PLOTTER */}
            <div className="space-y-2">
              <div className="text-[10px] text-slate-500 uppercase tracking-widest font-bold flex justify-between items-center">
                <span>Frame Render Latency</span>
                <span className="font-mono text-[9px] text-[#00ffff]">{latencyHistory[latencyHistory.length - 1]?.toFixed(1)} ms</span>
              </div>
              
              <div className="bg-[#07070a] border border-[#1c1c24] rounded p-2 flex flex-col items-center">
                
                {/* Elegant real SVG line graph */}
                <svg className="w-full h-16 text-emerald-400 bg-[#0c0c10]/40 rounded overflow-hidden" viewBox="0 0 100 30" preserveAspectRatio="none">
                  {/* Grid Lines */}
                  <line x1="0" y1="5" x2="100" y2="5" stroke="#222" strokeWidth="0.3" strokeDasharray="1,1" />
                  <line x1="0" y1="15" x2="100" y2="15" stroke="#222" strokeWidth="0.3" strokeDasharray="1,1" />
                  <line x1="0" y1="25" x2="100" y2="25" stroke="#222" strokeWidth="0.3" strokeDasharray="1,1" />
                  
                  {/* Dynamic Area Under Curve */}
                  <path
                    d={`M 0,30 ${latencyHistory.map((val, idx) => {
                      const x = (idx / (latencyHistory.length - 1)) * 100;
                      // scale y: average frame is 16.6ms -> map values cleanly
                      const y = Math.max(2, Math.min(28, 30 - ((val - 8) / 16) * 15));
                      return `L ${x},${y}`;
                    }).join(' ')} L 100,30 Z`}
                    fill="url(#latencyGrad)"
                    opacity="0.15"
                  />

                  {/* Latency Line */}
                  <polyline
                    fill="none"
                    stroke="#ff00ff"
                    strokeWidth="1.2"
                    points={latencyHistory.map((val, idx) => {
                      const x = (idx / (latencyHistory.length - 1)) * 100;
                      const y = Math.max(2, Math.min(28, 30 - ((val - 8) / 16) * 15));
                      return `${x},${y}`;
                    }).join(' ')}
                  />

                  {/* Definitions for Gradients */}
                  <defs>
                    <linearGradient id="latencyGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                      <stop offset="0%" stopColor="#ff00ff" />
                      <stop offset="100%" stopColor="#000" stopOpacity="0" />
                    </linearGradient>
                  </defs>
                </svg>
                
                <div className="w-full flex justify-between text-[8px] text-slate-600 mt-1 font-mono uppercase tracking-widest">
                  <span>-1.2s</span>
                  <span>render target: 16.6ms</span>
                  <span>now</span>
                </div>
              </div>
            </div>

          </div>

          {/* Connected Device Footprint */}
          <div className="p-3 border-t border-[#1c1c24] bg-[#0c0c0e] text-[9px] text-slate-600 space-y-0.5 font-mono shrink-0 uppercase tracking-widest">
            <div>Device: Neural_Grid_Link_95</div>
            <div>Auth: OAUTH_CYBERNET_GRANTED</div>
            <div>Secure: 256-Bit SSL Loopback</div>
          </div>
        </aside>

      </div>

      {/* WORKSPACE FOOTER STATUS BAR */}
      <footer className="h-6 border-t border-[#1c1c24] bg-[#0c0c0e] flex items-center px-4 justify-between text-[10px] text-slate-500 shrink-0 font-mono z-20">
        <div className="flex items-center space-x-4">
          <span className="text-slate-400 font-bold flex items-center gap-1 text-[10px]">
            <span className="text-[#00ffff]">●</span>
            SYS_STATUS: RUNNING
          </span>
          <span className="text-slate-600">|</span>
          <span>MEMORY_METRIC: <span className="text-slate-400">42.8 MB</span> / 512 MB</span>
          <span className="text-slate-600 hidden sm:inline">|</span>
          <span className="hidden sm:inline">RENDERER: <span className="text-pink-400 font-bold">WEBGL_GPU</span></span>
        </div>
        <div className="flex items-center space-x-4">
          <span className="text-slate-400">UTF-8</span>
          <span>TypeScript</span>
          <span className="text-[#00ffff] font-bold">THREE.js + Rapier</span>
        </div>
      </footer>

    </div>
  );
}
