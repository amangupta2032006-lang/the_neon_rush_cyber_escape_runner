/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';

export enum GameState {
  MENU = 'MENU',
  RUNNING = 'RUNNING',
  PAUSED = 'PAUSED',
  GAMEOVER = 'GAMEOVER',
}

export type Lane = -1 | 0 | 1; // Left, Center, Right

export interface PlayerStats {
  score: number;
  coins: number;
  multiplier: number;
  distance: number;
  highScore: number;
  highCoins: number;
}

export interface HoverboardSkin {
  id: string;
  name: string;
  color: string; // Hex code
  secondaryColor: string;
  price: number;
  unlocked: boolean;
  trailParticles: number;
  description: string;
}

export interface ObstacleType {
  id: string;
  type: 'BARRIER_LOW' | 'BARRIER_HIGH' | 'HOVER_CAR' | 'DRONE' | 'RAMP';
  width: number;
  height: number;
  depth: number;
  color: string;
}

export interface ActiveEntity {
  id: string;
  mesh: THREE.Object3D;
  type: 'COIN' | 'OBSTACLE' | 'SPEED_BOOST' | 'SHIELD';
  lane: Lane;
  zPos: number;
  yPos: number;
  collisionWidth: number;
  collisionHeight: number;
  collisionDepth: number;
  active: boolean;
  hasLogTriggered?: boolean;
  // For dynamic movement
  speedY?: number;
  speedZ?: number;
}

export interface RoadChunk {
  mesh: THREE.Group;
  zPos: number;
  active: boolean;
  entities: ActiveEntity[];
}
