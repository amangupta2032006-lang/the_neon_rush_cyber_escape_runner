/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

class AudioEngine {
  private ctx: AudioContext | null = null;
  private bgmInterval: any = null;
  private isMuted: boolean = false;
  private tempo: number = 120; // BPM
  private currentStep: number = 0;

  constructor() {
    // Initialized on user interaction to comply with browser autoplay policies
    this.isMuted = localStorage.getItem('neon_rush_muted') === 'true';
  }

  private init() {
    if (this.ctx) return;
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (AudioContextClass) {
      this.ctx = new AudioContextClass();
    }
  }

  setMute(muted: boolean) {
    this.isMuted = muted;
    localStorage.setItem('neon_rush_muted', String(muted));
    if (muted) {
      this.stopBGM();
    } else {
      this.startBGM();
    }
  }

  getMuted() {
    return this.isMuted;
  }

  playCoin() {
    this.init();
    if (!this.ctx || this.isMuted) return;

    const now = this.ctx.currentTime;
    const osc1 = this.ctx.createOscillator();
    const osc2 = this.ctx.createOscillator();
    const gainNode = this.ctx.createGain();

    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(987.77, now); // B5
    osc1.frequency.setValueAtTime(1318.51, now + 0.08); // E6

    osc2.type = 'triangle';
    osc2.frequency.setValueAtTime(1318.51, now);
    osc2.frequency.setValueAtTime(1975.53, now + 0.08); // B6

    gainNode.gain.setValueAtTime(0.08, now);
    gainNode.gain.exponentialRampToValueAtTime(0.001, now + 0.25);

    osc1.connect(gainNode);
    osc2.connect(gainNode);
    gainNode.connect(this.ctx.destination);

    osc1.start(now);
    osc2.start(now);
    osc1.stop(now + 0.25);
    osc2.stop(now + 0.25);
  }

  playJump() {
    this.init();
    if (!this.ctx || this.isMuted) return;

    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gainNode = this.ctx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(150, now);
    osc.frequency.exponentialRampToValueAtTime(600, now + 0.15);

    gainNode.gain.setValueAtTime(0.12, now);
    gainNode.gain.exponentialRampToValueAtTime(0.001, now + 0.2);

    osc.connect(gainNode);
    gainNode.connect(this.ctx.destination);

    osc.start(now);
    osc.stop(now + 0.2);
  }

  playSlide() {
    this.init();
    if (!this.ctx || this.isMuted) return;

    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const filter = this.ctx.createBiquadFilter();
    const gainNode = this.ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(300, now);
    osc.frequency.exponentialRampToValueAtTime(80, now + 0.25);

    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(600, now);
    filter.frequency.exponentialRampToValueAtTime(150, now + 0.25);

    gainNode.gain.setValueAtTime(0.1, now);
    gainNode.gain.exponentialRampToValueAtTime(0.001, now + 0.3);

    osc.connect(filter);
    filter.connect(gainNode);
    gainNode.connect(this.ctx.destination);

    osc.start(now);
    osc.stop(now + 0.3);
  }

  playSwoosh() {
    this.init();
    if (!this.ctx || this.isMuted) return;

    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gainNode = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(120, now);
    osc.frequency.exponentialRampToValueAtTime(350, now + 0.08);
    osc.frequency.exponentialRampToValueAtTime(100, now + 0.15);

    gainNode.gain.setValueAtTime(0.15, now);
    gainNode.gain.exponentialRampToValueAtTime(0.001, now + 0.15);

    osc.connect(gainNode);
    gainNode.connect(this.ctx.destination);

    osc.start(now);
    osc.stop(now + 0.15);
  }

  playCrash() {
    this.init();
    if (!this.ctx || this.isMuted) return;

    const now = this.ctx.currentTime;
    
    // Create white noise buffer
    const bufferSize = this.ctx.sampleRate * 0.8;
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = Math.random() * 2 - 1;
    }

    const noise = this.ctx.createBufferSource();
    noise.buffer = buffer;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(500, now);
    filter.frequency.exponentialRampToValueAtTime(50, now + 0.6);

    const gainNode = this.ctx.createGain();
    gainNode.gain.setValueAtTime(0.4, now);
    gainNode.gain.exponentialRampToValueAtTime(0.001, now + 0.8);

    // Also add a low bass rumble oscillator
    const rumble = this.ctx.createOscillator();
    rumble.type = 'sawtooth';
    rumble.frequency.setValueAtTime(100, now);
    rumble.frequency.exponentialRampToValueAtTime(30, now + 0.5);

    const rumbleGain = this.ctx.createGain();
    rumbleGain.gain.setValueAtTime(0.25, now);
    rumbleGain.gain.exponentialRampToValueAtTime(0.001, now + 0.5);

    noise.connect(filter);
    filter.connect(gainNode);
    gainNode.connect(this.ctx.destination);

    rumble.connect(rumbleGain);
    rumbleGain.connect(this.ctx.destination);

    noise.start(now);
    rumble.start(now);

    noise.stop(now + 0.8);
    rumble.stop(now + 0.8);
  }

  playPowerup() {
    this.init();
    if (!this.ctx || this.isMuted) return;

    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gainNode = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(300, now);
    osc.frequency.exponentialRampToValueAtTime(900, now + 0.3);

    gainNode.gain.setValueAtTime(0.12, now);
    gainNode.gain.exponentialRampToValueAtTime(0.001, now + 0.4);

    osc.connect(gainNode);
    gainNode.connect(this.ctx.destination);

    osc.start(now);
    osc.stop(now + 0.4);
  }

  playBeep() {
    this.init();
    if (!this.ctx || this.isMuted) return;

    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gainNode = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(440, now);

    gainNode.gain.setValueAtTime(0.05, now);
    gainNode.gain.exponentialRampToValueAtTime(0.001, now + 0.1);

    osc.connect(gainNode);
    gainNode.connect(this.ctx.destination);

    osc.start(now);
    osc.stop(now + 0.1);
  }

  startBGM() {
    this.init();
    if (!this.ctx || this.isMuted) return;
    if (this.bgmInterval) return;

    const stepDuration = 60 / this.tempo / 4; // 16th notes
    this.currentStep = 0;

    const playStep = () => {
      if (this.isMuted || !this.ctx) return;
      const now = this.ctx.currentTime;

      // Simple techno / synthwave loop sequencer
      // Step: 0 to 15 (1 bar loop)
      const step = this.currentStep % 16;

      // 1. Kick drum (Steps 0, 4, 8, 12)
      if (step === 0 || step === 4 || step === 8 || step === 12) {
        const kickOsc = this.ctx.createOscillator();
        const kickGain = this.ctx.createGain();

        kickOsc.type = 'sine';
        kickOsc.frequency.setValueAtTime(150, now);
        kickOsc.frequency.exponentialRampToValueAtTime(45, now + 0.1);

        kickGain.gain.setValueAtTime(0.18, now);
        kickGain.gain.exponentialRampToValueAtTime(0.001, now + 0.15);

        kickOsc.connect(kickGain);
        kickGain.connect(this.ctx.destination);

        kickOsc.start(now);
        kickOsc.stop(now + 0.15);
      }

      // 2. Hi-hat (Steps 2, 6, 10, 14, and sometimes offbeats)
      if (step % 2 === 1 || step === 2 || step === 6 || step === 10 || step === 14) {
        const hatBuffer = this.ctx.createBuffer(1, this.ctx.sampleRate * 0.05, this.ctx.sampleRate);
        const hatData = hatBuffer.getChannelData(0);
        for (let i = 0; i < hatBuffer.length; i++) {
          hatData[i] = Math.random() * 2 - 1;
        }

        const hatSource = this.ctx.createBufferSource();
        hatSource.buffer = hatBuffer;

        const hatFilter = this.ctx.createBiquadFilter();
        hatFilter.type = 'highpass';
        hatFilter.frequency.setValueAtTime(8000, now);

        const hatGain = this.ctx.createGain();
        const volume = (step % 4 === 2) ? 0.04 : 0.02; // Accent on offbeat kick
        hatGain.gain.setValueAtTime(volume, now);
        hatGain.gain.exponentialRampToValueAtTime(0.001, now + 0.04);

        hatSource.connect(hatFilter);
        hatFilter.connect(hatGain);
        hatGain.connect(this.ctx.destination);

        hatSource.start(now);
        hatSource.stop(now + 0.05);
      }

      // 3. Cyber Bassline Arpeggio
      // Progressive electro notes: E1, G1, A1, B1
      const bassNotes = [41.20, 41.20, 49.00, 49.00, 55.00, 55.00, 61.74, 61.74]; // Freqs for E1, G1, A1, B1
      const noteIdx = Math.floor(step / 2) % bassNotes.length;
      const bassFreq = bassNotes[noteIdx];

      const bassOsc = this.ctx.createOscillator();
      const bassFilter = this.ctx.createBiquadFilter();
      const bassGain = this.ctx.createGain();

      bassOsc.type = 'sawtooth';
      bassOsc.frequency.setValueAtTime(bassFreq, now);

      bassFilter.type = 'lowpass';
      bassFilter.frequency.setValueAtTime(250, now);

      bassGain.gain.setValueAtTime(0.06, now);
      bassGain.gain.exponentialRampToValueAtTime(0.001, now + stepDuration * 0.9);

      bassOsc.connect(bassFilter);
      bassFilter.connect(bassGain);
      bassGain.connect(this.ctx.destination);

      bassOsc.start(now);
      bassOsc.stop(now + stepDuration * 0.9);

      // 4. Lead Melody on half-notes (synth pad style)
      // Play a cool cyberpunk chord sweep on steps 0, 8
      if (step === 0 || step === 8) {
        const leadNotes = step === 0 ? [164.81, 196.00, 246.94] : [196.00, 246.94, 293.66]; // E3 minor / G3 major
        leadNotes.forEach((freq) => {
          const leadOsc = this.ctx.createOscillator();
          const leadGain = this.ctx.createGain();
          const leadFilter = this.ctx.createBiquadFilter();

          leadOsc.type = 'triangle';
          leadOsc.frequency.setValueAtTime(freq, now);

          leadFilter.type = 'lowpass';
          leadFilter.frequency.setValueAtTime(1200, now);
          leadFilter.Q.setValueAtTime(4, now);

          leadGain.gain.setValueAtTime(0.015, now);
          leadGain.gain.exponentialRampToValueAtTime(0.001, now + stepDuration * 6);

          leadOsc.connect(leadFilter);
          leadFilter.connect(leadGain);
          leadGain.connect(this.ctx.destination);

          leadOsc.start(now);
          leadOsc.stop(now + stepDuration * 6);
        });
      }

      this.currentStep++;
    };

    // Use a precise intervals scheduler in Web Audio
    const runScheduler = () => {
      playStep();
      this.bgmInterval = setTimeout(runScheduler, stepDuration * 1000);
    };

    runScheduler();
  }

  stopBGM() {
    if (this.bgmInterval) {
      clearTimeout(this.bgmInterval);
      this.bgmInterval = null;
    }
  }
}

export const gameAudio = new AudioEngine();
