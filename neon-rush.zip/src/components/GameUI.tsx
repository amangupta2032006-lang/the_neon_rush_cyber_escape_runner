/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { GameState, PlayerStats, HoverboardSkin } from '../types';
import { gameEngine } from '../engine/GameEngine';
import { gameAudio } from './AudioEngine';
import { Volume2, VolumeX, Play, Pause, RefreshCw, Trophy, Zap, Shield, Sparkles, Coins, Award } from 'lucide-react';

interface GameUIProps {
  gameState: GameState;
  stats: PlayerStats;
  onStartGame: () => void;
}

export default function GameUI({ gameState, stats, onStartGame }: GameUIProps) {
  const [muted, setMuted] = useState(false);
  const [activeSkinId, setActiveSkinId] = useState('cyber_neon');
  const [unlockedSkinIds, setUnlockedSkinIds] = useState<string[]>(['cyber_neon']);

  // Pre-load cyberpunk boards
  const SKINS: HoverboardSkin[] = [
    {
      id: 'cyber_neon',
      name: 'Cyber Neon',
      color: '#00ffff',
      secondaryColor: '#ff00ff',
      price: 0,
      unlocked: true,
      trailParticles: 40,
      description: 'Classic grid-runners standard Issue.',
    },
    {
      id: 'toxic_green',
      name: 'Radical Acid',
      color: '#39ff14',
      secondaryColor: '#00ff00',
      price: 30,
      unlocked: false,
      trailParticles: 50,
      description: 'Corrosive waste energy hover board.',
    },
    {
      id: 'crimson_laser',
      name: 'Crimson Fury',
      color: '#ff0055',
      secondaryColor: '#aa0033',
      price: 60,
      unlocked: false,
      trailParticles: 60,
      description: 'Overclocked red laser drift thruster.',
    },
    {
      id: 'solar_gold',
      name: 'Solar Overlord',
      color: '#ffdd00',
      secondaryColor: '#ff7700',
      price: 120,
      unlocked: false,
      trailParticles: 80,
      description: 'Prestige gold chassis built for kings.',
    },
    {
      id: 'void_purple',
      name: 'Nebula Void',
      color: '#a020f0',
      secondaryColor: '#4b0082',
      price: 250,
      unlocked: false,
      trailParticles: 100,
      description: 'Infused with dark matter propulsion coils.',
    },
  ];

  // Load skins state
  useEffect(() => {
    const savedUnlocked = localStorage.getItem('neon_rush_unlocked_skins');
    if (savedUnlocked) {
      try {
        setUnlockedSkinIds(JSON.parse(savedUnlocked));
      } catch (e) {
        setUnlockedSkinIds(['cyber_neon']);
      }
    }
    const savedActive = localStorage.getItem('neon_rush_active_skin');
    if (savedActive) {
      setActiveSkinId(savedActive);
      const skin = SKINS.find((s) => s.id === savedActive);
      if (skin) {
        gameEngine.setSkin(skin);
      }
    }

    setMuted(gameAudio.getMuted());
  }, []);

  const handleToggleMute = () => {
    const nextMute = !muted;
    setMuted(nextMute);
    gameAudio.setMute(nextMute);
    gameAudio.playBeep();
  };

  const selectSkin = (skin: HoverboardSkin) => {
    gameAudio.playBeep();
    if (unlockedSkinIds.includes(skin.id)) {
      setActiveSkinId(skin.id);
      localStorage.setItem('neon_rush_active_skin', skin.id);
      gameEngine.setSkin(skin);
    } else {
      // Try to buy!
      if (stats.coins >= skin.price) {
        // Deduct coins
        const nextCoins = stats.coins - skin.price;
        stats.coins = nextCoins;
        localStorage.setItem('neon_rush_total_coins', String(nextCoins));

        const nextUnlocked = [...unlockedSkinIds, skin.id];
        setUnlockedSkinIds(nextUnlocked);
        localStorage.setItem('neon_rush_unlocked_skins', JSON.stringify(nextUnlocked));

        setActiveSkinId(skin.id);
        localStorage.setItem('neon_rush_active_skin', skin.id);
        gameEngine.setSkin(skin);
        gameAudio.playPowerup();
      } else {
        // Can't afford
        gameAudio.playCrash(); // buzz noise
      }
    }
  };

  return (
    <div className="absolute inset-0 pointer-events-none flex flex-col font-sans select-none text-white z-10">
      
      {/* 1. MAIN MENU SCREEN */}
      {gameState === GameState.MENU && (
        <div className="pointer-events-auto flex flex-col items-center justify-between w-full h-full bg-gradient-to-b from-[#06020c]/60 via-[#0a0015]/90 to-[#020005] p-6 text-center animate-fade-in overflow-y-auto">
          
          {/* Top Panel & Logo */}
          <div className="w-full max-w-lg mt-4">
            <div className="flex justify-between items-center mb-6">
              <div className="flex items-center space-x-2 text-[#00ffff]">
                <Award className="w-5 h-5" />
                <span className="text-xs font-mono tracking-wider uppercase">V-1.09 Cybernet</span>
              </div>
              <button
                onClick={handleToggleMute}
                className="p-2.5 rounded-xl border border-[#00ffff]/20 bg-[#00ffff]/5 hover:bg-[#00ffff]/15 cursor-pointer text-[#00ffff] pointer-events-auto transition-colors duration-200"
                id="toggle-mute"
              >
                {muted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
              </button>
            </div>

            <div className="relative inline-block mb-1 group">
              <h1 className="text-5xl md:text-6xl font-black tracking-tighter text-transparent bg-clip-text bg-gradient-to-r from-[#00ffff] via-[#ff00ff] to-[#00ffff] drop-shadow-[0_4px_12px_rgba(0,255,255,0.4)] animate-pulse uppercase">
                NEON RUSH
              </h1>
              <div className="absolute -inset-0.5 bg-[#00ffff]/20 blur-xl opacity-35 group-hover:opacity-75 transition duration-500"></div>
            </div>
            <p className="text-sm font-mono tracking-[0.25em] text-[#ff00ff] uppercase mb-4">
              Cyber Escape Runner
            </p>

            {/* High Score Panel */}
            <div className="grid grid-cols-2 gap-3 bg-black/50 border border-[#00ffff]/20 rounded-2xl p-4 backdrop-blur-md">
              <div className="flex flex-col items-center border-r border-[#00ffff]/10">
                <span className="flex items-center text-[#ffdd00] text-xs font-mono uppercase tracking-wider mb-1">
                  <Trophy className="w-4 h-4 mr-1.5" /> High Score
                </span>
                <span className="text-2xl font-bold font-mono text-[#00ffff] tracking-wide">
                  {stats.highScore.toLocaleString()}
                </span>
              </div>
              <div className="flex flex-col items-center">
                <span className="flex items-center text-[#00ffff] text-xs font-mono uppercase tracking-wider mb-1">
                  <Coins className="w-4 h-4 mr-1.5" /> Total Coins
                </span>
                <span className="text-2xl font-bold font-mono text-[#ff00ff] tracking-wide">
                  {stats.coins}
                </span>
              </div>
            </div>
          </div>

          {/* Center: Hoverboard Skin shop */}
          <div className="w-full max-w-xl my-4">
            <h3 className="text-xs font-mono tracking-wider uppercase text-[#00ffff]/70 mb-3 flex items-center justify-center">
              <Sparkles className="w-4 h-4 mr-1.5" /> Select Glider Skin
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-3.5">
              {SKINS.map((skin) => {
                const isUnlocked = unlockedSkinIds.includes(skin.id);
                const isActive = activeSkinId === skin.id;

                return (
                  <button
                    key={skin.id}
                    onClick={() => selectSkin(skin)}
                    className={`relative p-3 rounded-2xl border text-center transition-all duration-300 pointer-events-auto cursor-pointer flex flex-col justify-between items-center ${
                      isActive
                        ? 'bg-gradient-to-b from-black/80 to-[#0a0015]/90 border-[#00ffff] shadow-[0_0_15px_rgba(0,255,255,0.3)] scale-[1.04]'
                        : isUnlocked
                        ? 'bg-black/40 border-gray-800 hover:border-[#ff00ff]/50'
                        : 'bg-black/60 border-[#ff00ff]/10 hover:border-[#ff00ff]/30'
                    }`}
                  >
                    {/* Glowing Board Dot indicator */}
                    <div
                      className="w-8 h-2.5 rounded-full mb-3 shadow-[0_0_8px_var(--color-shadow)]"
                      style={{
                        backgroundColor: skin.color,
                        boxShadow: `0 0 10px ${skin.color}`,
                      }}
                    />
                    
                    <span className="text-[11px] font-bold font-mono tracking-tight text-white/90 line-clamp-1">
                      {skin.name}
                    </span>

                    {/* Price / Unlock state */}
                    <div className="mt-2.5">
                      {isActive ? (
                        <span className="text-[10px] font-mono text-[#00ffff] font-bold tracking-widest uppercase">
                          ACTIVE
                        </span>
                      ) : isUnlocked ? (
                        <span className="text-[9px] font-mono text-gray-400 uppercase tracking-widest">
                          SELECT
                        </span>
                      ) : (
                        <span className="flex items-center text-[10px] font-mono font-bold text-[#ffdd00]">
                          <Coins className="w-3 h-3 mr-0.5 text-yellow-500" />
                          {skin.price}
                        </span>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Bottom Panel: Swipe Instructions & CTAs */}
          <div className="w-full max-w-md mb-3 flex flex-col items-center">
            {/* Guide Info */}
            <div className="text-[11px] font-mono text-gray-400 mb-5 max-w-xs leading-relaxed border-t border-gray-900/40 pt-4">
              <span className="text-[#00ffff]">CONTROL NET:</span> Swipe / Arrow keys to Lane Switch. Jump up to dodge low barriers. Slide down to escape laser gates!
            </div>

            {/* Launch Game CTA */}
            <button
              onClick={onStartGame}
              className="group relative w-full py-4 rounded-2xl bg-gradient-to-r from-[#00ffff] to-[#ff00ff] font-bold text-lg text-black uppercase tracking-widest hover:scale-105 transition duration-300 pointer-events-auto shadow-[0_0_20px_rgba(0,255,255,0.4)] hover:shadow-[0_0_30px_rgba(255,0,255,0.6)] cursor-pointer"
              id="start-button"
            >
              <span className="flex items-center justify-center space-x-2">
                <Play className="w-5 h-5 fill-current" />
                <span>INITIATE RUSH</span>
              </span>
            </button>
          </div>
        </div>
      )}

      {/* 2. GAME HUD SCREEN */}
      {gameState === GameState.RUNNING && (
        <div className="flex flex-col justify-between w-full h-full p-4 md:p-6">
          
          {/* Top HUD */}
          <div className="flex justify-between items-start">
            
            {/* Left Box: Score */}
            <div className="bg-black/60 border border-[#00ffff]/20 rounded-2xl p-3 md:p-4 backdrop-blur-md min-w-[140px]">
              <div className="text-[10px] font-mono uppercase tracking-widest text-[#00ffff]/80 mb-0.5">
                NEURAL CORE SCORE
              </div>
              <div className="text-2xl font-black font-mono tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-white to-[#00ffff]">
                {stats.score.toLocaleString()}
              </div>
              <div className="flex items-center text-xs font-mono text-[#ff00ff] mt-1">
                <span className="text-gray-400">MULT:</span>
                <span className="font-bold ml-1">{stats.multiplier}x</span>
                <span className="text-gray-400 ml-4">DIST:</span>
                <span className="font-bold ml-1 text-[#00ffff]">{Math.floor(stats.distance)}m</span>
              </div>
            </div>

            {/* Middle: Pause Trigger */}
            <button
              onClick={() => gameEngine.pauseGame()}
              className="pointer-events-auto p-3.5 bg-black/60 border border-gray-800 hover:border-[#ff00ff]/30 rounded-2xl text-gray-400 hover:text-white transition cursor-pointer"
              id="pause-button"
            >
              <Pause className="w-5 h-5" />
            </button>

            {/* Right Box: Level Coins */}
            <div className="bg-black/60 border border-[#ff00ff]/20 rounded-2xl p-3 md:p-4 backdrop-blur-md flex items-center space-x-3.5">
              <div className="text-right">
                <div className="text-[10px] font-mono uppercase tracking-widest text-[#ff00ff]/80 mb-0.5">
                  LEVEL COINS
                </div>
                <div className="text-2xl font-black font-mono tracking-wider text-[#ffdd00]">
                  {stats.coins}
                </div>
              </div>
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-yellow-500 to-amber-400 flex items-center justify-center shadow-[0_0_12px_rgba(253,224,71,0.4)]">
                <Coins className="w-5 h-5 text-black" />
              </div>
            </div>
          </div>

          {/* Bottom active state gauges */}
          <div className="flex flex-col space-y-2 max-w-xs self-start mb-6">
            {/* Speed Boost indicator */}
            {gameEngine['speedBoostActive'] && (
              <div className="flex items-center space-x-3 bg-[#00ff00]/10 border border-[#00ff00]/30 rounded-xl px-3.5 py-2 backdrop-blur-md animate-pulse">
                <Zap className="w-4 h-4 text-[#00ff00]" />
                <span className="text-xs font-mono font-bold tracking-wider text-[#00ff00] uppercase">
                  OVERDRIVE ACTIVE ({Math.ceil(gameEngine['speedBoostTimer'])}s)
                </span>
              </div>
            )}

            {/* Shield Active indicator */}
            {gameEngine['shieldActive'] && (
              <div className="flex items-center space-x-3 bg-[#00ffff]/10 border border-[#00ffff]/30 rounded-xl px-3.5 py-2 backdrop-blur-md animate-pulse">
                <Shield className="w-4 h-4 text-[#00ffff]" />
                <span className="text-xs font-mono font-bold tracking-wider text-[#00ffff] uppercase">
                  DEFLECTOR ACTIVE ({Math.ceil(gameEngine['shieldTimer'])}s)
                </span>
              </div>
            )}
          </div>
        </div>
      )}

      {/* 3. PAUSED SCREEN OVERLAY */}
      {gameState === GameState.PAUSED && (
        <div className="pointer-events-auto flex items-center justify-center w-full h-full bg-black/85 backdrop-blur-md animate-fade-in p-6">
          <div className="w-full max-w-sm bg-gradient-to-b from-[#0a0015] to-black border border-[#00ffff]/30 rounded-3xl p-6 text-center shadow-[0_0_40px_rgba(0,255,255,0.2)]">
            <h2 className="text-3xl font-black tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-[#00ffff] to-[#ff00ff] uppercase mb-1">
              HYPERLINK STANDBY
            </h2>
            <p className="text-[10px] font-mono uppercase tracking-widest text-[#ff00ff]/80 mb-6">
              Neural simulation paused
            </p>

            <div className="space-y-4 mb-6">
              {/* Quick Settings: Mute */}
              <button
                onClick={handleToggleMute}
                className="w-full py-3 rounded-2xl border border-gray-800 bg-white/5 hover:bg-white/10 flex items-center justify-center space-x-2 text-sm font-mono tracking-wider text-gray-300 transition cursor-pointer"
              >
                {muted ? (
                  <>
                    <VolumeX className="w-4 h-4 text-red-500" />
                    <span>MUTED</span>
                  </>
                ) : (
                  <>
                    <Volume2 className="w-4 h-4 text-green-400" />
                    <span>AUDIO ON</span>
                  </>
                )}
              </button>

              <button
                onClick={() => gameEngine.resumeGame()}
                className="w-full py-3.5 rounded-2xl bg-[#00ffff] hover:bg-[#00ffff]/80 font-bold text-black uppercase tracking-wider transition cursor-pointer"
                id="resume-btn"
              >
                RESUME RUN
              </button>

              <button
                onClick={() => onStartGame()}
                className="w-full py-3 rounded-2xl border border-[#ff00ff]/30 bg-[#ff00ff]/5 hover:bg-[#ff00ff]/15 font-bold text-[#ff00ff] uppercase tracking-wider transition cursor-pointer"
                id="restart-btn"
              >
                REBOOT TRACK
              </button>
            </div>

            <button
              onClick={() => {
                gameEngine.state = GameState.MENU;
                gameEngine.cleanUp();
                window.location.reload();
              }}
              className="text-xs font-mono text-gray-500 hover:text-white uppercase tracking-wider transition underline cursor-pointer"
            >
              Disconnect Link (Main Menu)
            </button>
          </div>
        </div>
      )}

      {/* 4. GAMEOVER SCREEN */}
      {gameState === GameState.GAMEOVER && (
        <div className="pointer-events-auto flex items-center justify-center w-full h-full bg-black/90 backdrop-blur-lg animate-fade-in p-6">
          <div className="w-full max-w-md bg-gradient-to-b from-[#100010] to-black border border-red-500/40 rounded-3xl p-6 text-center shadow-[0_0_50px_rgba(239,68,68,0.25)]">
            
            <div className="relative inline-block mb-3">
              <h2 className="text-4xl font-black tracking-tight text-[#ff0055] uppercase animate-pulse">
                LINK SEVERED
              </h2>
              <div className="absolute -inset-0.5 bg-red-500/10 blur-md opacity-50"></div>
            </div>
            
            <p className="text-xs font-mono uppercase tracking-[0.2em] text-gray-500 mb-6">
              CRASH RECOVERY MODULE ACTIVE
            </p>

            {/* Performance analysis */}
            <div className="bg-black/40 border border-red-500/10 rounded-2xl p-5 space-y-3.5 mb-6 text-left">
              <div className="flex justify-between items-center">
                <span className="text-xs font-mono text-gray-400 uppercase">FINAL SCORE</span>
                <span className="text-2xl font-black font-mono text-white tracking-wide">
                  {stats.score.toLocaleString()}
                </span>
              </div>
              <div className="flex justify-between items-center border-t border-gray-900 pt-2">
                <span className="text-xs font-mono text-gray-400 uppercase">DISTANCE GLIDED</span>
                <span className="text-base font-bold font-mono text-[#00ffff]">
                  {Math.floor(stats.distance)}m
                </span>
              </div>
              <div className="flex justify-between items-center border-t border-gray-900 pt-2">
                <span className="text-xs font-mono text-gray-400 uppercase">COINS COLLECTED</span>
                <span className="text-base font-bold font-mono text-[#ffdd00] flex items-center">
                  <Coins className="w-4 h-4 mr-1 text-yellow-500" />
                  {stats.coins}
                </span>
              </div>
            </div>

            {/* High score beat celebration */}
            {stats.score >= stats.highScore && stats.score > 0 && (
              <div className="mb-6 py-2 bg-gradient-to-r from-[#00ffff]/10 via-[#ff00ff]/10 to-[#00ffff]/10 border-y border-[#00ffff]/20 flex items-center justify-center space-x-2.5 animate-bounce">
                <Sparkles className="w-5 h-5 text-[#ff00ff]" />
                <span className="text-xs font-mono font-black tracking-widest text-[#00ffff] uppercase">
                  NEW RECORD ESTABLISHED!
                </span>
                <Sparkles className="w-5 h-5 text-[#00ffff]" />
              </div>
            )}

            <div className="grid grid-cols-2 gap-4">
              <button
                onClick={onStartGame}
                className="py-4 rounded-2xl bg-gradient-to-r from-[#ff00ff] to-[#ff0055] font-bold text-sm tracking-widest text-white uppercase hover:scale-105 transition duration-200 shadow-[0_0_15px_rgba(255,0,85,0.3)] cursor-pointer"
                id="retry-btn"
              >
                <span className="flex items-center justify-center space-x-1.5">
                  <RefreshCw className="w-4 h-4" />
                  <span>RESPAWN</span>
                </span>
              </button>
              
              <button
                onClick={() => {
                  gameEngine.state = GameState.MENU;
                  gameEngine.cleanUp();
                  window.location.reload();
                }}
                className="py-4 rounded-2xl border border-gray-800 bg-white/5 hover:bg-white/10 font-bold text-sm tracking-widest text-gray-300 uppercase hover:scale-105 transition duration-200 cursor-pointer"
                id="menu-btn"
              >
                STATION
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
